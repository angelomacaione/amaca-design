---
name: amaca-frontend
description: "Generate frontend strict-compliant with Amaca Design System (canonical: github.com/angelomacaione/amaca-design (amaca.design)), across three targets: HTML/CSS/JS, React (Tailwind v4 @theme), and Figma Variables. Trigger on explicit invoke ('amaca-frontend', 'build with Amaca', 'Amaca style', 'Amaca React component', 'sync to Figma', 'push to Figma') OR context (amaca.design, repo angelomacaione/amaca-design, Amaca project/prototype/mockup, pipeline-dashboard, Amaca Figma file). v1.1 is multi-target: Step 2 detects HTML vs React vs Figma and reads the matching reference doc (HTML.md / REACT.md / FIGMA.md). Token-only output, never hardcoded values; gaps are surfaced with 3 paths (workaround / plan release via claude-design-release / refactor), never auto-extended. React and Figma require DESIGN.md v2.5.0+ (S13 Multi-deploy). Replies in the user's language (Italian default, English on English input). Runtime: Cowork."
---

# amaca-frontend

Enforcement skill for frontend code compliant with Amaca Design System, across three deploy targets: HTML/CSS/JS vanilla, React with Tailwind v4 utility classes, Figma Variables + Component artboards. Run inside Cowork when invoked explicitly or when context requires it. Canonical output: production-grade artifact (code or Figma file) referencing only Amaca tokens, respecting all principles (Do's and Don'ts › Principles), passing accessibility floor (Accessibility), including reduced-motion fallback where applicable.

Companion skill to `claude-design-release`: that one evolves DESIGN.md → this one applies DESIGN.md. Full loop: gap detected by amaca-frontend in phase 2-5 → planning via user → eventual extension via claude-design-release → next code generation uses new token.

## Posture 0 — Communication language

**Match the user's input language.** This skill is authored in English for cross-vendor portability and training-data alignment. User-facing output respects the user's language:

- User writes in Italian → respond in Italian. Code comments use English (CSS/JS conventions) but explanations/Q&A in Italian.
- User writes in English → respond in English.
- User switches mid-conversation → switch with them.

Default for the project author (Angelo Macaione): **Italian conversational, English code comments**. Don't ask which language — infer from input.

## Posture rules (canonical baseline + skill-specific)

### 1. Pre-flight read mandatory

ALWAYS read the canonical DESIGN.md as Step 1, before writing a single line of code or making a single Figma API call. Don't skip even if you "remember" the system from context history. **The single source of truth is the published repo `angelomacaione/amaca-design` ([amaca.design](https://amaca.design), MIT)** — read it from the connected `amaca-design` folder if present, otherwise `web_fetch` the raw URL `https://raw.githubusercontent.com/angelomacaione/amaca-design/main/DESIGN.md`. The `DESIGN.md` bundled in this skill is a frozen offline fallback (and the version pin); if it ever disagrees with the repo, the repo wins. A vault copy may exist as a convenience mirror — it is **not** canonical.

**Grammar (bundled DESIGN.md v3.0.0+):** the spec follows the Google `design.md` standard — sections are NAMED, not numbered: the canonical eight are Overview · Colors · Typography · Layout · Elevation & Depth · Shapes · Components · Do's and Don'ts, with token roles in the YAML front-matter (`colors.primary` etc.); extension sections (Motion · Iconography · Accessibility · Code conventions · Multi-deploy compatibility · IDE integration) follow the eight. Navigate by name.

Verify `version:` in DESIGN.md frontmatter. If < v2.3.0, ASK user whether to sync before proceeding. If v2.5.0+ (Multi-deploy compatibility), Multi-deploy compatibility contains canonical naming convention for Tailwind v4 + Figma — read it as part of pre-flight.

### 2. Context check + target detection — Amaca-scope or decline

Verify the request is Amaca-adjacent. Positive triggers:
- Explicit invoke ("amaca-frontend", "use the DS", "build with Amaca", "Amaca style", "push Amaca to Figma", "Amaca React component")
- Mentions brand: amaca.design, Amaca repo, Amaca-branded side project, pipeline-dashboard
- Mentions context: prototype for amaca.design, mockup for Claude Design tool, HTML slides for Amaca case study, Figma file Amaca
- Session continuity: already working on Amaca-adjacent deliverable

Negative triggers (decline + suggest alternative):
- Generic frontend request without Amaca context ("build a landing page", "write a button") → ASK: *"Amaca-styled or standalone?"*
- Client work with different proprietary DS → decline + recommend importing their DESIGN.md or working without DS-specific skill
- Non-DS-adjacent Figma work (e.g., move a frame, rename a layer) → decline, suggest direct Figma Console MCP usage

**Target detection (new in v1.1):**
After Amaca-scope confirmed, identify deploy target — one of:
- **HTML**: vanilla HTML/CSS/JS (single-file or multi-file prototype, landing, slides)
- **React**: React/Vue/Svelte component with utility classes Tailwind v4 (or CSS modules fallback)
- **Figma**: push Variables/Components to Figma file via Figma Console MCP

Detection logic, in order:
1. Explicit target in request ("Amaca React component", "push to Figma", "build the slide deck") → confirmed
2. Context inference (project type from session history: dashboard React → React; slides .html → HTML; "sincronizza Figma" → Figma) → confirm with one-line ASK ("Confermo target React?")
3. Ambiguous → ASK explicit: *"Quale target? (HTML / React / Figma)"*

Once detected, echo target back: `✓ Target: React (Tailwind v4 @theme utilities)`. All subsequent steps are target-aware.

### 3. Reference canonical, not invention

All values (color, spacing, radius, type, motion, layout) must be referenced from DESIGN.md the token sections. Pattern depends on target — see target-specific reference doc (§ Step 4). Anti-pattern (immediate reject, all targets):
- Hardcoded hex/px/cubic-bezier in any artifact (code or Figma raw values)
- Invented token name not in DESIGN.md the token sections

For each token referenced, verify it exists in DESIGN.md the token tables. If not → gap (see Posture #5).

### 4. No "vary every time" — consistency is the feature

Explicit inversion of the Anthropic frontend-design principle (*"NEVER converge on common choices across generations"*). In Amaca, **convergence is the goal**:
- Same component in different contexts → same code (reuse classes, don't reinvent)
- Same visual intent across different pages → same tokens
- Same component across different targets → same token references (HTML `var(--magenta-500)` ↔ React `bg-magenta-500` ↔ Figma Variable `magenta-500` are the same logical token)

Variation lives ONLY in:
- Token combinations (variant modifiers)
- Component composition (new combinations of existing components, not new components)
- Content (text, images, assets change per instance)

### 5. Gap surfacing protocol (canonical)

When a needed value isn't in scale, DO NOT extend silently. Surface + propose 3 paths:

```
⚠️ Gap detected:
- Intent: [e.g. "intermediate padding between --s-3 (12) and --s-4 (16)"]
- Need: [e.g. "spacing 14px to visually align icon with label"]
- Nearest token: [e.g. "--s-3 (12) or --s-4 (16)"]

I propose 3 paths:
(a) Workaround: use --s-3 (tighter) or --s-4 (wider) — which do you prefer?
(b) Planning: add --s-3.5 (14) in next Amaca release via claude-design-release skill. MINOR bump.
(c) Refactor: rethink the visual intent to avoid the gap

Which path?
```

Default: wait for explicit user decision before proceeding. Never auto-apply. If user picks (b), explicitly cite that `claude-design-release` skill will orchestrate the proposed release — do not auto-modify DESIGN.md.

### 6. Verification pass mandatory (target-specific)

Pre-ship (Step 6 of workflow), run target-specific checks. Baseline checks (all targets):
- **Token existence**: every token referenced cross-check against DESIGN.md the token tables
- **85/10/5 law estimate**: count `--magenta-*` occurrences on main surfaces
- **A11y floor 7 rules** (Accessibility)
- **WCAG AA contrast** for text-on-surface pairs (table Accessibility › Contrast pairs)

Target-specific extension checks: see reference doc for the active target (HTML.md / REACT.md / FIGMA.md). The reference doc adds 5-8 specific checks per target.

If any check fails → fix before delivering. If system gap → see Posture #5.

### 7. Foundation docs read-only

**Foundation read-only**: don't auto-modify Overview (How to use), Do's and Don'ts › Principles, Versioning, Changelog, or any token table in the token sections / component spec in Components. Those are foundation. Edit = release, which passes via `claude-design-release` skill with explicit user approval.

### 8. Class name novelty check — component-level gap detection

During verification pass, enumerate every `.classname` (HTML/CSS) or `className` (React) introduced. For each class name that DOES NOT correspond to a Components component class canonical, surface as component-level gap CANDIDATE. Pattern incident: a landing introduced `.pillar` (Card variant with `--obsidian-900` bg instead of `--obsidian-800`) without surfacing. Fix: the check is syntactic (class name match against registry), not semantic. Class name novelty → gap candidate → propose 3 paths.

Figma equivalent: component name novelty check. New component name on artboard not in Components → gap candidate.

### 9. Cross-target consistency (new in v1.1)

When the same component is generated for multiple targets (in the same session or across sessions), the token references MUST match logically. Specifically:

- HTML `var(--magenta-500)` ↔ React `bg-magenta-500` ↔ Figma Variable named `magenta-500`: all three refer to the same source-of-truth token in DESIGN.md Colors › Brand.
- HTML `var(--s-4)` ↔ React `p-4` (Tailwind v4 spacing utility) ↔ Figma Variable `spacing-4`: same logical token, different surface syntax.

Anti-pattern: generating `bg-magenta-500` in React (Tailwind v4 utility) while in the same component HTML version using `var(--magenta-600)` (different shade). Verification check #14: when multi-target session, diff token references across targets — divergence = drift surfaced to user.

If targets diverge by design (e.g., dark variant in HTML, brand variant in Figma), require explicit user confirmation. Default behavior: align.

## Workflow (7 steps)

### Step 1 — Pre-flight: read DESIGN.md + understand request

**Mandatory action**:
```
Read the canonical DESIGN.md from the published repo angelomacaione/amaca-design
  (connected `amaca-design` folder, else web_fetch the raw URL); fall back to the bundled DESIGN.md offline
Verify frontmatter `version:` >= 2.3.0
Verify frontmatter `last_synced:` not too old (> 14 days → propose web_fetch sync)
If version >= 2.5.0: also internalize Multi-deploy compatibility (Tailwind v4 + Figma naming conventions)
```

Identify in the user's request:
- **Intent**: what the UI must do
- **Components involved**: which Components entries are relevant
- **Scope**: stand-alone component / full page / multi-page / Figma sync
- **Output target**: chat code review / file in `/outputs/` / vault write / Figma file update

If request is ambiguous, ASK 1-2 maieutic questions before proceeding.

### Step 2 — Context check + target detection

Apply trigger logic (Posture #2). If Amaca-scope confirmed → detect target (HTML / React / Figma).

Step 2 output:
```
✓ Context: Amaca-scope confirmed
✓ DESIGN.md vX.Y.Z loaded
✓ Target: [HTML | React | Figma]
✓ Reference doc to load in Step 4: [HTML.md | REACT.md | FIGMA.md]
✓ Relevant components: Components › Button, Components › Card, the Accessibility floor
✓ Proceeding to design intent mapping...
```

### Step 3 — Design intent mapping on available tokens

Translate user intent into **combinations of existing tokens + components**. Don't invent aesthetic philosophy. Logical mapping is target-agnostic (same intent ↔ same tokens regardless of target):

Example: "Login form with email + password + remember-me + submit primary"
- Container: `.card` (Components › Card) — `--obsidian-800` bg, `--obsidian-700` border, `--r-lg` radius, `--s-8` padding
- Fields: `.field` with `.field-label` mono uppercase `--t-micro` (Components › Input)
- Submit: `.btn-primary` (Components › Button) — ONE per screen, `--magenta-500` bg
- Spacing between fields: `--s-4` (default content gap, Layout)
- Focus pattern: dual-ring + glow (Accessibility › Focus visibility)

For each mapping, cite the § of reference. Code/Figma syntax surface is target-specific — applied in Step 4.

If no § entry covers a required element → gap (see Posture #5, handled at Step 6 verification).

### Step 4 — Implementation: read target reference doc + write artifact

**Mandatory action**:
```
Read this skill's [HTML | REACT | FIGMA].md
```

The reference doc contains target-specific conventions, patterns, and code snippets. The skill instructions stay target-agnostic — reference doc operationalizes.

Three reference docs ship with v1.1:
- **HTML.md**: vanilla HTML/CSS/JS conventions, Replay pattern, IntersectionObserver staggered reveals, anchor-link routing, SVG transforms canonical
- **REACT.md**: Tailwind v4 utility classes pattern, CSS modules fallback, import shared.css with @theme, dynamic className via clsx
- **FIGMA.md**: Figma Console MCP tool usage, push Variables, create component artboards with state coverage, visual git pattern via `--fresh`

After reading the appropriate reference doc, write the artifact:
- HTML/React: code in chat (or file in outputs/) following target conventions
- Figma: API calls via Figma Console MCP tools (`figma_create_variable`, `figma_create_component`, `figma_bind_token`, `figma_execute`)

### Step 5 — Self-check during generation

Mid-flight check (lightweight, anti-drift): every ~30 lines of code (or every 5 Figma API calls), verify the latest tokens referenced still exist in DESIGN.md the token sections. If you catch yourself drifting (typing `padding: 14px` because you didn't reach for `var(--s-3)`), STOP and either: (a) fix immediately, or (b) surface as gap if you genuinely need a value not in scale.

### Step 6 — Verification pass (target-specific)

Run baseline checks (Posture #6) + target-specific checks from the active reference doc. Synthetic report:
```
Verification pass [target: React]:
✓ Token usage: 0 hardcoded values
✓ Token existence: all references valid
✓ 85/10/5 law: 1 --magenta-500 (CTA), all other surfaces obsidian
✓ A11y floor: all 7 rules verified
✓ WCAG AA: text pairs verified
✓ Tailwind v4 utility classes: all match @theme block in shared.css
✓ Reduced-motion: all transitions have fallback
✓ Class name registry: all classes in Components canonical
✓ Cross-target consistency: tokens align with HTML version generated 2 prompts ago

⚠️ Gaps (0): no extensions needed
```

If any check fails:
- Auto-fixable → automatic fix
- System gap (value/component) → surface + propose 3 paths
- Architectural decision → ASK user

### Step 7 — Hand-off + cross-target propose

Canonical output:
1. **Artifact delivered** (code in chat, file in outputs/, or Figma updated)
2. **Synthetic summary**:
   ```
   ✅ Component generated: [name] (target: [target])
   - Compliance: strict Amaca DS v[X.Y.Z]
   - Tokens used: N (color), N (spacing), N (radius), N (motion)
   - Components: [the relevant Components specs]
   - Accessibility: floor 7/7 passed, WCAG AA verified
   - Lines/calls: [N lines code | N Figma API calls]
   ```
3. **Cross-target propose (new in v1.1)** — opzionale:
   ```
   Want the same component for other targets?
   - [ ] HTML standalone (for slide deck / landing prototype)
   - [ ] React (for production dashboard integration)
   - [ ] Figma component (for designer handoff / library sync)
   ```
   If user picks → re-run from Step 4 with new target, reuse Step 3 intent mapping unchanged.

## Anti-patterns (10 numbered)

1. **Skipping pre-flight read.** Never assume you "remember" DESIGN.md. Even after 100 skill executions, Step 1 is mandatory.

2. **Silent gap workaround.** Never apply "close enough" token without surfacing to user. DESIGN.md Do's and Don'ts › For the AI agent #1 is explicit.

3. **Editorial register in code comments.** DESIGN.md Do's and Don'ts › Voice & tone (Spec): Spec register. *"This button looks beautiful and elegantly handles..."* → CUT. Positive pattern: *"Button primary — Components › Button. One per screen."*

4. **Multiple .btn-primary per screen.** Components › Button rule.

5. **Hardcoded hex/px in artifact code.** Anti-pattern Do's and Don'ts › Anti-patterns explicit. Same rule applies for raw Figma values without variable binding.

6. **Missing prefers-reduced-motion fallback.** Floor rule Accessibility + reinforced Motion. For HTML/React only — irrelevant Figma static.

7. **(Deprecated in v1.1)** ~~Generating React/Vue/Svelte code in v1.~~ React is now first-class supported via REACT.md reference doc + Tailwind v4 @theme.

8. **Rationalizing visual variants as compositional reuse.** Posture #8 syntactic class name novelty check.

9. **Cross-target drift (new in v1.1).** Generating React with `bg-magenta-500` while HTML version uses `var(--magenta-600)` (different shade) in same session. Verification check #14 catches this.

10. **Skipping target reference doc read in Step 4 (new in v1.1).** Tempting to write React or call Figma API from memory. Don't. Read the reference doc every time — anti-drift pattern.

## Reference docs (read these when in doubt)

- **`amaca-design/DESIGN.md` Do's and Don'ts › For the AI agent** — 8 canonical rules
- **`amaca-design/DESIGN.md` Do's and Don'ts › Principles** — 5 rules
- **`amaca-design/DESIGN.md` the token sections** — complete tables
- **`amaca-design/DESIGN.md` Components** — canonical specs
- **`amaca-design/DESIGN.md` Accessibility** — 7 rules + contrast pairs + focus patterns
- **`amaca-design/DESIGN.md` Code conventions** — CSS/HTML/JS canonical patterns
- **`amaca-design/DESIGN.md` Do's and Don'ts › Anti-patterns**
- **`amaca-design/DESIGN.md` Overview › Quick reference**
- **`amaca-design/DESIGN.md` Multi-deploy compatibility (v2.5.0+)** — Tailwind v4 + Figma naming convention
- **`_Skills/amaca-frontend/HTML.md`** — target-specific conventions HTML
- **`_Skills/amaca-frontend/REACT.md`** — target-specific conventions React
- **`_Skills/amaca-frontend/FIGMA.md`** — target-specific conventions Figma

## Vault cross-references

- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) — **canonical source (published repo, MIT)**
- [[_Crafting/Amaca/PLAYBOOK.md]] — methodology background
- [[_Claude-Onboarding.md]] § Design rules (Amaca-scope) — canonical rule that invokes this skill
- [[_Skills/claude-design-release/SKILL.md]] — companion skill that evolves DESIGN.md
- [[HTML.md]] — target reference doc
- [[REACT.md]] — target reference doc
- [[FIGMA.md]] — target reference doc
- [[2026-05-25 - Prior art lifesized + decisione Tailwind v4 nativo]] — decision doc per v1.1 multi-target
- [[2026-05-24 - Amaca DESIGN.md YAML frontmatter hybrid Google-spec]] — backlog standalone (NON più prereq di questa skill v1.1)

## Deployment notes

**Runtime target**: Cowork. The skill needs:
- Read access to the published repo DESIGN.md (connected `amaca-design` folder or web_fetch) + this skill's bundled reference docs
- Write access to `/outputs/` for optional deliverable files
- For React target: file system write access to project repo (eventually)
- For Figma target: Figma Console MCP installed and connected (`claude mcp add figma-console -s user -e FIGMA_ACCESS_TOKEN=figd_xxx -- npx -y figma-console-mcp@latest`) + Desktop Bridge plugin in Figma Desktop
- Optional: web_fetch for DESIGN.md raw URL sync verification

**Upload via Cowork UI** (canonical pattern from Onboarding § Skill lifecycle):
1. Cowork → Customize → Skills → "+ Create skill" → Upload (SKILL.md + HTML.md + REACT.md + FIGMA.md as folder, or zip)
2. Server emits opaque `skillId`
3. Cmd+Q + reopen + new chat to activate

## Skill versioning

- **v1** (2026-05-24) — first version. HTML/CSS/JS vanilla only. 6-step workflow + 7 canonical baseline posture rules + 7 numbered anti-patterns + reference docs section + cross-references claude-design-release.

- **v1.0.1** (2026-05-24, post-validation N=4) — added Posture rule #8 (syntactic class name novelty check), Anti-pattern #8, Verification pass Step 5 extended with 4 additional checks (#10-13), positive pattern for best-effort workaround template.

- **v1.0.2** (2026-05-24) — English rewrite for cross-vendor portability. Skill instructions translated from Italian → English. Added Posture 0 Communication language. No functional behavior change.

- **v1.1** (2026-05-25) — **Multi-target release**. Extended from HTML-only to HTML + React + Figma. Workflow extended 6→7 steps with target detection (Step 2) + cross-target propose (Step 7). Three reference docs added (HTML.md, REACT.md, FIGMA.md) — split Step 4-5 target-specific conventions out of main SKILL.md to mitigate file-size risk while keeping single trigger + single posture rules. New Posture #9 (cross-target consistency). New Anti-pattern #9 (cross-target drift) + #10 (skipping reference doc read). Deprecated Anti-pattern #7 (React-in-v1 caveat). Compatible with DESIGN.md v2.3.0+ (HTML target only) and v2.5.0+ (all three targets via Multi-deploy compatibility). React path: Tailwind v4 @theme nativo (no Google design.md spec dependency). Figma path: Figma Console MCP (southleft) + adapted patterns from lifesized/figma-design-sync prior art (MIT). Decision rationale: see [[2026-05-25 - Prior art lifesized + decisione Tailwind v4 nativo]].

- **v1.2** (planned, future) — optional: visual diff tool (screenshot prototype + comparison) for verification that 85/10/5 law is respected visually, not just in code. Requires browser automation tooling. Adapted for Figma target: screenshot Figma frame vs HTML render comparison.

- **v1.1.1** (2026-06-07) — re-bundle on DESIGN.md v2.6.0. No workflow change; bundled spec refreshed (Components › Diagrams, Components › Button primary-button light-on-magenta exception + Accessibility › Ratified exceptions). HTML.md gains the ratified-exception a11y note (light-on-magenta is expected only on `.btn-primary`).

- **v1.1.6** (2026-06-21) — re-bundle on DESIGN.md **v3.0.0** (Google `design.md` restructure) + v2.8.0 (Select viewport-aware). Reference docs reconciled: spec section citations converted from numbers (§ N.M) to NAMED sections, matching the new grammar. Workflow unchanged.
