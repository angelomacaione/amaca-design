# amaca-frontend skill

Enforcement skill for generating HTML/CSS/JS frontend strict-compliant with **Amaca Design System v2.3.0+**. Inverts the "vary every time" pattern of standard generation skills — here **convergence is the goal**: same tokens, same patterns, same motion choreography across every generated component.

## What's in this bundle

- **`SKILL.md`** — the skill (YAML frontmatter + 6-step workflow + posture rules + anti-patterns)
- **`DESIGN.md`** — canonical design system v2.3.0 that the skill reads as Step 1 mandatory. **Bundled to ensure off-line enforcement** — no vault dependencies, no remote fetches.
- **`README.md`** — this file

## Installation

### Cowork / Claude Code / Cursor / Continue / Windsurf / Aider

Anthropic skill format is cross-tool. Upload via target runtime UI:

1. Open the runtime → Skills section (in Cowork: Customize → Skills)
2. "+ Create skill" / "Upload a skill"
3. Drag-and-drop the `.skill` file (renamed zip), or upload folder contents as ZIP
4. Server emits opaque skillId
5. Restart runtime + new chat to activate

### Installation test

In a new chat, invoke:

```
amaca-frontend: build me a primary button that says "Continue"
```

The skill should:
1. Read bundled DESIGN.md (Step 1 mandatory)
2. Confirm Amaca-scope context
3. Map intent to § 3.1 Button (primary variant)
4. Generate HTML/CSS with token references only (`var(--magenta-500)`, `var(--s-2)`, etc.)
5. Run verification pass (13 checks)
6. Hand off code + summary

If you get code with hardcoded values (`#F051D5` instead of `var(--magenta-500)`, `200ms` instead of `var(--d-quick)`), the skill isn't enforcing DESIGN.md correctly. Verify installation + runtime compatibility (see caveat below).

## Use cases

**When the skill triggers**:
- Explicit invoke: `"amaca-frontend"`, `"build with Amaca"`, `"Amaca style"`, `"Amaca-styled prototype"`
- Context-based: request mentions `amaca.design`, repo `angelomacaione/amaca-design`, Amaca-branded side project

**When it DOESN'T trigger** (decline + suggest alternative):
- Generic frontend without Amaca context ("build a landing page") → ASK if Amaca-styled or standalone
- Client work with different proprietary DS → decline + recommend importing their DESIGN.md or working without DS-specific enforcement
- React/Vue/Svelte components in v1 → decline with caveat (React-via-Tailwind v1.1 future when YAML hybrid release lands)

## Gap handling

If a needed value isn't in DESIGN.md § 2 Tokens (e.g., spacing 14px between `--s-3` 12 and `--s-4` 16), or a component isn't in § 3 (e.g., checkbox pre-v2.4.0, radio, tooltip), the skill **doesn't extend silently** — it surfaces the gap explicitly and proposes 3 paths:

(a) **Workaround**: use nearest token or compose existing patterns — quick fix, not canonical
(b) **Planning release**: add the missing piece to DS via MINOR release — disciplined but delayed
(c) **Refactor intent**: rethink visual intent to avoid the gap

You decide. The skill waits.

## Communication language

The skill itself is authored in English for cross-vendor portability (LLMs follow English instructions with higher fidelity, especially non-Anthropic runtimes). But output respects user language: writes in Italian if you write Italian, English if you write English. Code comments stay English (CSS convention universal). No language toggle needed — inferred from input.

## Skill ecosystem (complete loop)

`amaca-frontend` is companion skill to `claude-design-release`:

```
amaca-frontend (Cowork/IDE)              claude-design-release (Claude Design tool)
        ↓                                          ↑
    APPLY DESIGN.md                         EVOLVE DESIGN.md
    (generate compliant code)               (release new components via git diff + SemVer)
        ↓                                          ↑
    Detect gap during                       Orchestrate release
    code generation                         (write files + verify + commit + tag + push)
        ↓                                          ↑
    Surface + 3 paths  ─────────────────  Path "Planning release" triggers
    (workaround/plan/refactor)            new MINOR/MAJOR bump
```

Productive loop: gap detected → planning → DESIGN.md evolves → next code generation uses new token. Emerging pattern: workaround so solid it can be promoted directly to canonical (Checkbox v2.4.0 followed this path).

## Runtime compatibility caveat

The skill is designed + validated for **Anthropic-stack runtimes** (Claude Code, Cowork, Cursor, Continue, Windsurf, Aider) where the bundled DESIGN.md is read via explicit tool calls (Read / file access). Validation N=4 in Cowork: average 8.5/10, exemplary 9.5/10 on gap workaround pattern.

**For other LLM vendors** (Gemini consumer, ChatGPT without Code Interpreter, etc.) compatibility is **best-effort**. Observed pattern: models that process file upload as "context embedding" without explicit tool call tend toward "performative compliance" — they announce reading DESIGN.md but generate code with invented values (training data drift). Empirical example: Gemini Flash free tier generated a landing page with `--magenta-500: #e11d48` (Tailwind rose-600) instead of canonical `#F051D5`. **Always manually verify generated token values against DESIGN.md if using non-Anthropic runtime.**

For Gemini specifically, the most reliable deployment is **Gems** (Gemini Advanced subscription): paste SKILL.md as system instructions + upload DESIGN.md as knowledge file. Free tier file upload is unreliable due to context-embedding architecture.

## Versioning

- **v1** (2026-05-24) — first version, HTML/CSS/JS vanilla only
- **v1.0.1** (2026-05-24) — post validation N=4: 1 new posture rule (#8 class name novelty check), 4 verification check additions (#10-13), 1 anti-pattern, positive pattern documented (best-effort workaround template)
- **v1.0.2** (2026-05-24) — English rewrite for cross-vendor portability + new Posture 0 (Communication language). No functional change.
- **v1.1** (planned) — React-via-Tailwind via `@google/design.md` export, unlocks when Amaca DESIGN.md gets YAML frontmatter Google-spec compliance
- **v1.2** (future) — visual diff tool for 85/10/5 verification via browser screenshots

## Source of truth

- **Amaca DS canonical**: GitHub repo [angelomacaione/amaca-design](https://github.com/angelomacaione/amaca-design) + site [amaca.design](https://amaca.design)
- **License**: MIT (DESIGN.md spec itself). Skill: freely include this bundle in your workflow.

## Credits

Skill design + DESIGN.md authoring: Angelo Macaione. Bundle prepared 2026-05-24, English rewrite same session.
