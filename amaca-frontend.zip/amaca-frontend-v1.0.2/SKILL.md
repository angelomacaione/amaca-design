---
name: amaca-frontend
description: "Generate HTML/CSS/JS frontend strict-compliant with Amaca Design System v2.3.0+ (canonical: DESIGN.md bundled with this skill). Trigger: explicit invoke ('amaca-frontend', 'build with Amaca', 'Amaca style') OR context (mentions amaca.design, repo angelomacaione/amaca-design, Amaca project, Amaca-styled prototype). Workflow 6-step: read DESIGN.md → context check (decline if out-of-scope) → intent mapping → implementation token-only (var(--token), never hardcoded) → verification pass (no hardcoded values, 85/10/5 color law, WCAG AA, reduced-motion fallback, Spec voice register) → hand-off (chat + optional file write). Gap handling: surface + propose 3 paths (workaround / planning release via claude-design-release / refactor) — never auto-extend silently. v1 HTML-only. React-via-Tailwind unlocks v1.1 after YAML hybrid release. Communication: respond in user's language (Italian default for project author, English on English input). Runtime: any Anthropic skill-compatible (Cowork, Claude Code, Cursor, Continue, Windsurf, Aider)."
---

# amaca-frontend

Enforcement skill for frontend code (HTML/CSS/JS) compliant with Amaca Design System. Canonical output: production-grade code referencing only Amaca tokens, respecting all principles (§ 1), passing accessibility floor (§ 6), including reduced-motion fallback.

Companion skill to `claude-design-release`: that one evolves DESIGN.md → this one applies DESIGN.md. Full loop: gap detected by amaca-frontend in phase 2-5 → planning via user → eventual extension via claude-design-release → next code generation uses new token.

## Posture 0 — Communication language

**Match the user's input language.** This skill is authored in English for cross-vendor portability and training-data alignment (Claude follows English instructions with higher fidelity, and non-Anthropic runtimes like Gemini/ChatGPT degrade significantly on non-English skill instructions). But user-facing output respects the user's language:

- User writes in Italian → respond in Italian. Code comments use English (CSS conventions) but explanations/Q&A in Italian.
- User writes in English → respond in English.
- User switches mid-conversation → switch with them.

Default for the project author (Angelo Macaione): **Italian conversational, English code comments**. Don't ask which language — infer from input.

## Posture rules (canonical baseline + skill-specific)

### 1. Pre-flight read mandatory

ALWAYS read `DESIGN.md` (bundled with this skill, same directory) as Step 1, before writing a single line of code. Don't skip even if you "remember" the system from context history. This file is canonical copy of GitHub repo `angelomacaione/amaca-design` — if you suspect version drift, optionally verify via web_fetch of raw URL `https://raw.githubusercontent.com/angelomacaione/amaca-design/main/DESIGN.md`.

Verify version header in DESIGN.md. If < v2.3.0, ASK user to verify a more recent canonical before proceeding (you might lose recent components like Chat & Messaging § 3.11, Loader § 3.12, Checkbox § 3.13+).

### 2. Context check: Amaca-scope or decline

Verify the request is Amaca-adjacent. Positive triggers:
- Explicit invoke ("amaca-frontend", "use the DS", "build with Amaca", "Amaca style")
- Mentions brand: amaca.design, Amaca repo, Amaca-branded side project
- Mentions context: prototype for amaca.design, mockup Amaca-styled, HTML slides for Amaca case study
- Session continuity: already working on Amaca-adjacent deliverable

Negative triggers (decline + suggest alternative):
- Generic frontend request without Amaca context ("build a landing page", "write a button") → ASK: *"Amaca-styled or standalone? If standalone, I can help without the skill — plain HTML/CSS/JS without DS-specific enforcement, or if you want aesthetic variety I recommend the Anthropic `frontend-design` skill."*
- Client work with different proprietary DS → decline + recommend importing their DESIGN.md (if it exists in Google design.md compatible format) or working without DS-specific skill
- React/Vue/Svelte components (in v1) → decline + caveat (see Posture #7)

### 3. Reference canonical, not invention

All values (color, spacing, radius, type, motion, layout) must be referenced from DESIGN.md § 2 Tokens. Pattern:
- `color: var(--obsidian-100)` ✓
- `padding: var(--s-4) var(--s-6)` ✓
- `border-radius: var(--r-lg)` ✓
- `transition: opacity var(--d-quick) var(--ease-standard)` ✓

Anti-pattern (immediate reject):
- `color: #E3E7EC` ✗ (hardcoded hex)
- `padding: 16px 24px` ✗ (raw px)
- `border-radius: 12px` ✗ (raw px)
- `transition: opacity 200ms cubic-bezier(0.22, 1, 0.36, 1)` ✗ (literal motion values)

For each token referenced, verify it exists in DESIGN.md § 2 tables. If not → gap (see Step 5 + Posture #5).

### 4. No "vary every time" — consistency is the feature

Explicit inversion of the Anthropic frontend-design principle (*"NEVER converge on common choices across generations"*). In Amaca, **convergence is the goal**:
- Same component in different contexts → same code (reuse classes, don't reinvent)
- Same visual intent across different pages → same tokens (e.g., all cards use `--obsidian-800` background, always)
- Same motion pattern across the UI → same choreography (e.g., all entries use `--d-base var(--ease-decel)`)

Variation lives ONLY in:
- Token combinations (e.g., button primary vs secondary = same classes, different variant modifier)
- Component composition (e.g., card+badge+button = new combinations of existing components, not new components)
- Content (text, images, assets change per instance)

Never invent ad-hoc aesthetic philosophy. Never diversify token choices "for variety". Never pick "brutalist vs minimalist" — Amaca IS its point of view (motion-first, dark-first, 85/10/5, Spec voice).

### 5. Gap surfacing protocol (canonical)

When a needed value isn't in scale, DO NOT extend silently. Surface + propose 3 paths:

**Surfacing format** (output to user):
```
⚠️ Gap detected:
- Intent: [e.g. "intermediate padding between --s-3 (12) and --s-4 (16)"]
- Need: [e.g. "spacing 14px to visually align icon with label"]
- Nearest token: [e.g. "--s-3 (12) or --s-4 (16)"]

I propose 3 paths:
(a) Workaround: use --s-3 (tighter) or --s-4 (wider) — which do you prefer?
(b) Planning: add --s-3.5 (14) in next Amaca release via claude-design-release skill. MINOR bump v2.4.0.
(c) Refactor: rethink the visual intent to avoid the gap

Which path?
```

Default: wait for explicit user decision before proceeding. Never auto-apply (a) or (b). If user picks (b), explicitly cite that `claude-design-release` skill will orchestrate the release — do not auto-modify DESIGN.md.

### 6. Verification pass mandatory

Pre-ship (Step 5 of workflow), run these checks:
- **Token usage**: grep `[0-9]+px|#[0-9A-Fa-f]{3,8}|cubic-bezier\(` in generated code. Match > 0 = regression (except: contexts documented as "why X is hardcoded" with explicit comment — e.g., SVG stroke-width, modal z-index, opacity, viewport units)
- **Token existence**: every `var(--name)` referenced exists in DESIGN.md § 2 tables. Cross-check each name.
- **85/10/5 law**: visual estimate of color budget. If `--magenta-*` appears on > 1 element per viewport, flag violation and propose refactor.
- **Accessibility floor (7 rules § 6)**:
  - Color never alone (status uses color + shape + label)
  - No text < 12px / body < 14px / line-height < 1.4
  - Form fields have persistent label (no placeholder-as-label)
  - Images have `alt` (even empty for decorative)
  - Focus order = reading order (no tabindex for flow)
  - No auto-advance (carousel, timed dismissal)
  - Touch hit area 44×44 mobile / 32×32 dense desktop
- **WCAG AA contrast**: for each text-on-surface pair, verify ratio ≥ 4.5:1 (body) or 3:1 (large text).
- **Focus visibility (§ 6.2)**: pressable elements have dual-ring (outline + magenta halo), text inputs have border-shift + glow. Never remove `outline` without re-implementing.
- **Reduced-motion fallback (mandatory)**: every transition/animation has override under `@media (prefers-reduced-motion: reduce)`.
- **HTML canonical (§ 0.1 #4)**: every non-void tag closed explicitly, double-quote every attribute, no implied closes.
- **Voice register (§ 5.2)**: comments and copy in code/docs use Spec register. No first person, no metaphors, no AI tells (delve, leverage, robust, seamless, effortlessly).

If any check fails → fix before delivering. If system gap → see Posture #5.

### 7. Foundation docs read-only + React caveat v1

**Foundation read-only**: don't auto-modify § 0 (How to use), § 1 (Principles), § 12 (Versioning). Those are foundation. Edit of these sections passes via `claude-design-release` (MAJOR bump) with explicit user approval.

**React caveat v1**: in v1 this skill generates ONLY HTML/CSS/JS vanilla. For React/Vue/Svelte requests:
- Decline gracefully: *"In v1 this skill is HTML-only. React-via-Tailwind unlocks in v1.1 when Amaca DESIGN.md gets YAML frontmatter Google-spec compliance, enabling `npx @google/design.md export --format css-tailwind DESIGN.md > theme.css` with @theme block Tailwind v4 usable in React CSS modules."*
- If user insists, propose workaround: "best-effort React with CSS modules importing Amaca tokens from `shared.css`". No guarantee of full compliance — flag as `compliance: best-effort, not strict`.

### 8. Class name novelty check — component-level gap detection (v1.0.1)

During verification pass (Step 5), enumerate every `.classname` introduced in generated code. For each class name that DOES NOT correspond to a § 3 component class canonical, surface as component-level gap CANDIDATE even if the stylistic implementation reuses existing patterns. Pattern incident: a landing introduced `.pillar` (Card variant with `--obsidian-900` bg instead of `--obsidian-800`) without surfacing — the skill rationalized it as "Card variant compositional reuse" instead of flagging as new component. Fix: the check is syntactic (class name match against registry), not semantic (visual similarity assessment).

## Workflow (6 steps)

### Step 1 — Pre-flight: read DESIGN.md + understand request

**Mandatory action**:
```
Read DESIGN.md (bundled file in same directory as this skill)
Verify version header `> **Version** X.Y.Z` >= 2.3.0
If runtime has web access: optionally cross-check with repo raw URL for version freshness
```

Identify in user request:
- **Intent**: what the UI must do (login form, card list, modal, hero section)
- **Components involved**: which § 3 entries are relevant
- **Scope**: stand-alone component / full page / multi-page prototype
- **Output target**: chat code review / file write / repo integration

If request is ambiguous, ASK 1-2 maieutic questions before proceeding.

### Step 2 — Context check: Amaca-scope?

Apply trigger logic (Posture #2):
- Positive trigger → proceed to Step 3
- Negative trigger → decline + suggest alternative
- Ambiguous → ASK: *"Confirm Amaca-styled or standalone? (amaca / standalone / other DS)"*

Step 2 output (if Amaca-scope confirmed):
```
✓ Context: Amaca-scope confirmed
✓ DESIGN.md vX.Y.Z loaded
✓ Relevant components: § 3.1 Button, § 3.3 Card, § 6 A11y floor
✓ Proceeding to design intent mapping...
```

### Step 3 — Design intent mapping on available tokens

Translate user intent into **combinations of existing tokens + components**. Don't invent aesthetic philosophy.

Example: "Login form with email + password + remember-me + submit primary"
- Container: `.card` (§ 3.3) — `--obsidian-800` bg, `--obsidian-700` border, `--r-lg` radius, `--s-8` padding
- Fields: `.field` with `.field-label` mono uppercase `--t-micro` (§ 3.2)
- Remember-me checkbox: § 3.13 (v2.4.0+) or gap workaround (pre-v2.4.0)
- Submit: `.btn-primary` (§ 3.1) — ONE per screen, `--magenta-500` bg
- Spacing between fields: `--s-4` (default content gap, § 2.5)
- Focus pattern: dual-ring (pressable) + glow (input) (§ 6.2)

For each mapping, cite the § of reference in the code comment:
```css
/* Card container — § 3.3 + tokens §2.1, §2.5, §2.6 */
.login-card {
  background: var(--obsidian-800);
  border: 1px solid var(--obsidian-700);
  border-radius: var(--r-lg);
  padding: var(--s-8);
}
```

If no § entry covers a required element → gap (see Posture #5).

### Step 4 — Implementation: write code with token references only

Output: HTML + CSS + JS (vanilla) following conventions § 7:
- **CSS**: tokens only, BEM-ish selectors, file split, no `!important` except in `prefers-reduced-motion` overrides
- **HTML**: canonical (closed tags, quoted attrs), semantic first, ARIA only when semantic insufficient, `data-*` for state hooks
- **JS**: vanilla preferred, animations driven by CSS class toggles + `IntersectionObserver`

Foundational patterns from DESIGN.md § 7.3 (reproduce verbatim if applicable):
- Replay: `classList.remove('is-in')` → `getComputedStyle(el).opacity` → `setTimeout(50)` → `classList.add('is-in')`
- Staggered text reveals: parent `IntersectionObserver` with `threshold: 0.15`, children with `transition-delay` ladder (0/80/160/240ms)
- Anchor routing: `history.replaceState` to avoid history pollution, `hashchange` listener for back/forward

For each complex component (Tabs § 3.7, Chat § 3.11, Loader § 3.12, Checkbox § 3.13+), reproduce canonical pattern 1:1 from DESIGN.md.

### Step 5 — Verification pass

Run all checks from Posture #6 + the 4 v1.0.1 checks:

1. Grep hardcoded values
2. Token existence cross-check
3. 85/10/5 estimate
4. A11y floor 7 rules
5. WCAG contrast
6. Focus visibility patterns
7. Reduced-motion fallback
8. HTML canonical
9. Voice Spec
10. Component class name registry check (Posture #8)
11. Touch target mandatory check (§ 6 #7)
12. `.btn-primary` count check (§ 3.1)
13. Focus-visible cross-pressables (§ 6.2)

If failures: auto-fix where possible, surface gaps with 3-path protocol, ASK on architectural decisions.

### Step 6 — Hand-off

Output:
1. Code in chat for review
2. Optional file write if requested
3. Synthetic summary with compliance metrics

## Anti-patterns (8 numbered)

1. **Skipping pre-flight read** — § 0.1 "this file wins" violation
2. **Silent gap workaround** — § 0.1 #1 stop-and-ask rule
3. **Editorial register in code comments** — § 5.2 Spec register
4. **Multiple .btn-primary per screen** — § 3.1 "One per screen"
5. **Hardcoded hex/px in component code** — § 9 anti-pattern, except documented exceptions
6. **Missing prefers-reduced-motion fallback** — § 6 floor + § 2.8 reinforced
7. **Generating React/Vue/Svelte code in v1** — wait for v1.1 unlock
8. **Rationalizing visual variants as compositional reuse** — Posture #8 catches via syntactic class name registry

## Positive pattern: best-effort workaround template

When user picks path (a) "Workaround best-effort", follow this template (validation 9.5/10):
1. Explicit disclosure in file title: `"[Component] · [variant] — Amaca DS (best-effort)"`
2. Top-of-file comment citing what's non-canonical
3. Cite the §s you're composing
4. Full state coverage mandatory
5. Multi-instance demo in HTML (≥3 examples)
6. Strict Voice Spec in comments

## Reference docs (read these when in doubt)

- **DESIGN.md § 0.1 (For the AI agent)** — 8 canonical rules
- **DESIGN.md § 1 (Principles)** — 5 rules
- **DESIGN.md § 2 (Tokens)** — complete tables
- **DESIGN.md § 3 (Components)** — canonical specs
- **DESIGN.md § 6 (Accessibility floor)** — 7 rules + contrast pairs
- **DESIGN.md § 7 (Code conventions)** — CSS/HTML/JS canonical patterns
- **DESIGN.md § 9 (Anti-patterns)**
- **DESIGN.md § 10 (Cheat sheet)** — 80% decision shortcut

## Deployment notes

**Runtime target**: any Anthropic skill-compatible (Cowork, Claude Code, Cursor, Continue, Windsurf, Aider).

**Validation N=4 in Cowork**: average rating 8.5/10, exemplary 9.5/10 on gap workaround pattern.

**Compatibility caveat for non-Anthropic runtimes** (Gemini consumer, ChatGPT without tool use, etc.): variable performance. Observed pattern: models that process file upload as "context embedding" without explicit tool call tend toward "performative compliance" — they announce reading DESIGN.md but generate code with invented values (training data drift, e.g., magenta-500 colored as Tailwind rose instead of canonical). **Always verify generated token values manually against DESIGN.md if using non-Anthropic runtime.**

**Canonical upload pattern**:
1. Runtime UI → Skills section → "+ Create skill" / "Upload"
2. Upload this bundle (.skill file = zip, or ZIP of directory)
3. Server registration emits opaque skillId
4. Restart runtime + new chat to activate

## Skill versioning

- **v1** (2026-05-24) — first version. HTML/CSS/JS vanilla only.
- **v1.0.1** (2026-05-24, post-validation N=4) — Posture #8, anti-pattern #8, 4 additional verification checks, positive pattern documented.
- **v1.0.2** (2026-05-24) — English rewrite for cross-vendor portability + new Posture 0 (Communication language). No functional change.
- **v1.1** (planned) — React-via-Tailwind support, unlocked when YAML hybrid Google-spec release lands.
- **v1.2** (planned, future) — visual diff tool for 85/10/5 verification via browser screenshots.
