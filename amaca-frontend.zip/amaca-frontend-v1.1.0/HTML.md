---
type: skill-reference-doc
parent_skill: amaca-frontend
target: HTML
version: 1.0
created: 2026-05-25
tags:
  - skill-reference
  - amaca
  - html
---

# HTML target — reference doc for amaca-frontend

> Conventions, patterns, and verification checks specific to **vanilla HTML/CSS/JS** target. Read by `amaca-frontend` SKILL.md Step 4 when target = HTML. Does not stand alone — requires the parent SKILL.md and DESIGN.md as canonical context.

## When this target applies

- Stand-alone HTML/CSS/JS prototype (slide deck, landing, single-page demo)
- Self-contained `.html` file with `<style>` inline or separate `tokens.css` + `components.css`
- Static export for Cowork artifact or Vercel hosting
- No build step required (no Vite, no Webpack, no Tailwind compile)

If the user wants utility classes auto-generated → switch to React target (Tailwind v4 build pipeline). If the user wants Figma push → switch to Figma target.

## Token reference syntax — HTML

All tokens referenced via CSS variable syntax: `var(--token-name)`.

Pattern:
```css
.login-card {
  background: var(--obsidian-800);
  border: 1px solid var(--obsidian-700);
  border-radius: var(--r-lg);
  padding: var(--s-8);
  transition: transform var(--d-quick) var(--ease-standard);
}
```

**Note v2.4.0+ compatibility**: if shared.css migrated to `@theme` block with namespaced tokens (`--color-magenta-500` instead of `--magenta-500`), HTML target supports BOTH naming conventions during transition. Tailwind v4 `@theme` block still exposes the variables at `:root` via runtime CSS variables. Reference DESIGN.md § 13 for canonical naming. If both exist, prefer namespaced version for forward compatibility.

## File layout convention

For multi-file projects:
```
project/
├── styles/
│   ├── tokens.css       # mirror of repo tokens.css (or @theme block if v2.4.0+)
│   └── components.css   # all .btn-*, .card, .field, etc.
└── index.html           # imports both via <link rel="stylesheet">
```

For single-file artifacts (Cowork output):
- Inline `<style>` block in `<head>` with tokens + components
- Inline `<script>` at end of `<body>` for JS (IIFE pattern to avoid global pollution)
- All `<link rel="preconnect">` for Satoshi CDN (Fontshare) before stylesheet load

## Code conventions § 7 — reproduced patterns

### Replay pattern (re-trigger CSS animation)

Canonical reproduction from DESIGN.md § 7.3:
```js
function replayAnimation(el) {
  el.classList.remove('is-in');
  void getComputedStyle(el).opacity;  // force reflow
  setTimeout(() => el.classList.add('is-in'), 50);
}
```

### Staggered text reveals (IntersectionObserver)

```js
const reveal = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-in');
      reveal.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('[data-reveal]').forEach(el => reveal.observe(el));
```

CSS for staggered children:
```css
[data-reveal] > * {
  opacity: 0;
  transform: translateY(8px);
  transition: opacity var(--d-base) var(--ease-decel), transform var(--d-base) var(--ease-decel);
}
[data-reveal].is-in > *:nth-child(1) { transition-delay: 0ms;   opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(2) { transition-delay: 80ms;  opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(3) { transition-delay: 160ms; opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(4) { transition-delay: 240ms; opacity: 1; transform: translateY(0); }
```

### Anchor-link routing (multi-page single-file)

```js
function goToSlide(num) {
  const id = `slide-${num}`;
  history.replaceState(null, '', `#${id}`);  // no history pollution
  document.getElementById(id).scrollIntoView({ behavior: 'instant' });
}
window.addEventListener('hashchange', () => {
  const id = location.hash.slice(1);
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
});
```

### SVG transforms canonical

Transform SVG groups via SVG attribute, not CSS, for sub-pixel precision:
```html
<g transform="translate(0,0) scale(1) rotate(0)" data-anim="reveal">
  <!-- children -->
</g>
```

CSS animation drives `data-anim` state, JS reads-and-writes `transform` attribute.

## Reduced-motion fallback (mandatory)

Global override in `tokens.css` (or inline `<style>`):
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

For specific components with complex orchestration:
```css
@media (prefers-reduced-motion: reduce) {
  .hero-reveal { transition: none; transform: none; }
  .stagger-children > * { transition-delay: 0ms; }
}
```

## Verification checks — HTML-specific

In addition to baseline checks (SKILL.md § Posture 6):

### H1. Grep hardcoded values
Regex: `[0-9]+px|#[0-9A-Fa-f]{3,8}|cubic-bezier\(`. Match > 0 = regression (except: SVG stroke-width with explicit `<!-- rationale -->` comment, modal z-index, opacity values, viewport units).

### H2. HTML canonical (§ 0.1 #4)
- Every non-void tag closed explicitly
- Every attribute double-quoted
- No implied closes
- ARIA only when semantic insufficient
- `data-*` for state hooks

### H3. Touch target mandatory (§ 6 #7)
For each clickable element, calculate effective height (height + padding-y). If < 44px and mobile-targetable → warning. Override with explicit rationale comment if intentional (e.g., dense desktop-only UI with 32×32 hit area).

### H4. `.btn-primary` count (§ 3.1)
Count occurrences. If > 1 in same screen/page → warning "One per screen" violation. Fix: convert extras to `.btn-secondary` or `.btn-ghost`.

### H5. Focus-visible cross-pressables (§ 6.2)
Every clickable/focusable element must have explicit `:focus-visible` styling. NO reliance on default browser outline. Pattern:
```css
.btn-primary:focus-visible {
  outline: 2px solid var(--magenta-500);
  outline-offset: 2px;
  box-shadow: 0 0 0 4px rgba(240, 81, 213, 0.3);  /* glow halo */
}
```

### H6. Replay pattern presence
If component has CSS animation triggered by class toggle, verify Replay pattern is used (force reflow with `getComputedStyle(el).opacity`). Without, second-trigger animation will not replay.

### H7. Preconnect for Satoshi
For pages using Satoshi (DESIGN.md § 2.4), verify `<link rel="preconnect" href="https://api.fontshare.com">` (or chosen CDN) appears BEFORE stylesheet `<link>`. No `@import` in CSS (blocks rendering).

## Anti-patterns specific to HTML target

1. **Using `@import` in CSS for fonts.** Always `<link rel="preconnect">` + `<link rel="stylesheet">` in `<head>`. `@import` blocks rendering.

2. **Inline `style="..."` for token values.** Tokens belong in CSS variables, not inline attributes. Exception: dynamic positioning calculated by JS (e.g., `style="--offset: ${px}px"` then CSS reads `var(--offset)`).

3. **`<div onclick>` for actions.** Use `<button>` for actions, `<a>` for nav. Never click handlers on non-interactive elements.

4. **Forgetting to call IIFE wrap on shared.js.** Shared JS file must IIFE-wrap to avoid global namespace pollution:
   ```js
   (function() {
     // shared code
   })();
   ```

## Hand-off output format — HTML

```
✅ Component generated: [name] (target: HTML)
- Compliance: strict Amaca DS v[X.Y.Z]
- Tokens used: N (color), N (spacing), N (radius), N (motion)
- Components: § 3.X, § 3.Y
- Accessibility: floor 7/7 passed, WCAG AA verified
- Lines: HTML XX / CSS XX / JS XX
- File: [path or "inline single-file"]

Optional next actions:
- Open in browser for visual test
- Run linter (e.g., stylelint, html-validate) if integrated project
- Test reduced-motion: System Preferences → Accessibility → Display → Reduce motion
- Test focus-visible: Tab through interactive elements
```

## Cross-references

- [[_Skills/amaca-frontend/SKILL.md]] — parent skill
- [[_Crafting/Amaca/DESIGN.md]] § 7 Code conventions
- [[_Crafting/Amaca/DESIGN.md]] § 2.8 Motion (reduced-motion fallback)
- [[_Crafting/Amaca/DESIGN.md]] § 6.2 Focus visibility patterns
- [[_Skills/amaca-frontend/REACT.md]] — sibling target reference
- [[_Skills/amaca-frontend/FIGMA.md]] — sibling target reference
