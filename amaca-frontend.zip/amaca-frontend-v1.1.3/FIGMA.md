---
type: skill-reference-doc
parent_skill: amaca-frontend
target: Figma
version: 1.0
created: 2026-05-25
tags:
  - skill-reference
  - amaca
  - figma
  - figma-console-mcp
---

# Figma target — reference doc for amaca-frontend

> Conventions, patterns, and verification checks specific to **Figma push** target. Read by `amaca-frontend` SKILL.md Step 4 when target = Figma. Adapted from prior art `lifesized/figma-design-sync` (MIT) — pattern reuse with Amaca-specific posture overlay. Does not stand alone — requires the parent SKILL.md, DESIGN.md as canonical context, and Figma Console MCP installed.

## When this target applies

- Push DESIGN.md tokens → Figma Variables (color, number, dimension, string)
- Create or update Component artboards in Figma (Button states, Card variants, Inputs, etc.)
- Generate documentation pages in Figma file (Color Palette, Typography, Spacing & Radii, Components)
- Audit existing Figma file against DESIGN.md (drift detection, dry-run report)
- Sync component state coverage (default / hover / focus / active / disabled / loading) per § 3 spec

If the user wants HTML/React code → switch to corresponding target. If the user wants new design exploration (not push from DESIGN.md) → decline + suggest designing in Figma natively first, then sync via this skill.

## Prerequisites

1. **Figma Console MCP installed and connected**:
   ```bash
   claude mcp add figma-console -s user -e FIGMA_ACCESS_TOKEN=figd_YOUR_TOKEN -- npx -y figma-console-mcp@latest
   ```
2. **Figma access token** from Figma Desktop → Settings → Security (starts with `figd_`)
3. **Desktop Bridge plugin** installed and running in Figma Desktop. Auto-connects via WebSocket localhost:9223 (local mode, recommended).
4. **Target Figma file open** in Figma Desktop on the page where push will land.

Verify connection at Step 4 entry: call `figma_get_status` (or equivalent first-call discovery) — if `initialized: false`, surface to user and STOP. Do not proceed with API calls that will fail silently.

## Figma Console MCP tools — subset used

Figma Console MCP exposes 59+ tools. The amaca-frontend Figma target uses a subset:

| Tool | Purpose |
|---|---|
| `figma_get_status` | Verify connection initialized |
| `figma_get_variables` | Read existing Variables in file (audit, drift detection) |
| `figma_create_variable` | Create a Color/Number/Dimension Variable |
| `figma_update_variable` | Update existing Variable value |
| `figma_create_node` | Create frame, rectangle, text node, group |
| `figma_bind_token` | Bind a node property (fill, stroke, padding) to a Variable |
| `figma_create_component` | Create reusable Component from a frame |
| `figma_get_screenshot` | Capture frame as image (verification) |
| `figma_execute` | Arbitrary Plugin API JavaScript (escape hatch for complex operations) |

For full tool registry, reference: https://docs.figma-console-mcp.southleft.com/

## Code-first push pattern (canonical for Amaca)

DESIGN.md is single source of truth. Figma is projection. Direction: code → Figma, NEVER Figma → code (unless explicit audit request).

### Token name mapping — DESIGN.md → Figma Variable

| DESIGN.md token | Figma Variable name | Type | Mode |
|---|---|---|---|
| `--magenta-500` | `color/magenta/500` | Color | Default |
| `--obsidian-800` | `color/obsidian/800` | Color | Default |
| `--success` | `color/semantic/success` | Color | Default |
| `--s-4` | `spacing/4` | Number (16) | Default |
| `--r-lg` | `radius/lg` | Number (12) | Default |
| `--t-body` | `typography/body/size` | Number (15) | Default |
| `--lh-normal` | `typography/lineHeight/normal` | Number (1.45) | Default |
| `--d-quick` | `motion/duration/quick` | Number (200) | Default |

**Convention**: slash-separated namespace mirrors DESIGN.md token hierarchy. Figma displays nested with `/` as folder separator natively. If v2.5.0+ Tailwind v4 namespaced names (`--color-magenta-500`) are in shared.css, strip the redundant prefix in Figma name (`color/magenta/500` not `color/color/magenta/500`).

### State coverage for components

Every component pushed to Figma must include canonical states (matching § 6.2 focus patterns + § 3 specs):

| Component § | Required states |
|---|---|
| 3.1 Button (primary/secondary/ghost/danger) | default · hover · focus-visible · active · disabled · loading |
| 3.2 Input | default · hover · focus · filled · error · disabled |
| 3.3 Card | default · hover (if interactive) |
| 3.7 Tabs | default · hover · active · disabled |
| 3.11 Chat message | sent · received · pending · failed |
| 3.12 Loader | spinner · skeleton · progress |

Pattern: each state is a separate Variant within the Figma Component, with property `state=hover` (etc.) bound to Variant property.

### Slash commands convention (inspired by lifesized prior art)

When user issues high-level Figma intent, map to canonical sub-actions:

- **"sync Amaca to Figma"** or **"push DESIGN.md to Figma"** → full sync: tokens + all § 3 components
- **"push tokens only"** → Variables only, skip Component artboards
- **"sync component Button"** or **"push Button to Figma"** → single component with all variants
- **"audit Figma vs DESIGN.md"** → READ Figma Variables, diff against DESIGN.md, output dry-run report
- **"snapshot Figma current page"** → visual git pattern: clone current page as `[date] - vX.Y.Z snapshot` before destructive sync

### Visual git pattern

Before any destructive sync (modifying existing Variables or Components), offer the user a snapshot:

```
⚠️ Sync will modify existing Variables in this Figma page.
Recommend snapshot first?
(a) Yes — clone page as "2026-05-25 - Pre-sync snapshot" (preserves history)
(b) No — proceed with in-place update
(c) Cancel
```

Implementation: use `figma_execute` to duplicate the current page programmatically before applying changes.

## Workflow inside Step 4 (Figma-specific)

After reading FIGMA.md (this file), proceed:

1. **Verify connection**: `figma_get_status` → confirm `initialized: true`. If not, STOP and surface to user.
2. **Identify scope**: full sync / tokens only / single component / audit. Confirm with user if ambiguous.
3. **Pre-flight diff**: call `figma_get_variables`. Diff against DESIGN.md § 2. Identify create / update / delete operations.
4. **Snapshot offer** (if destructive): visual git pattern above.
5. **Apply operations in order**:
   a. Create/update Color Variables (Obsidian + Magenta + Supporting + Semantic)
   b. Create/update Number Variables (Spacing + Radius + Typography size + Motion duration)
   c. Create/update Component artboards (one per § 3 entry) with state variants
   d. Bind nodes to Variables (every fill, stroke, corner radius, padding token-bound)
6. **Generate documentation pages** (if full sync):
   - Color Palette page with swatch grid (one rect per Color Variable, label below)
   - Typography page with type scale samples in Satoshi
   - Spacing & Radii page with visual samples
7. **Verification screenshots**: `figma_get_screenshot` on each generated artboard. Visual evidence of compliance.

## Verification checks — Figma-specific

In addition to baseline checks (SKILL.md § Posture 6):

### F1. Variable name canonical
Every Variable created must follow slash-namespace convention (`color/magenta/500`). Drift = surface (e.g., user previously created `magenta500` flat name → propose rename via `figma_update_variable`).

### F2. Token value exact match
Every Variable value must match DESIGN.md § 2 byte-for-byte. Hex colors lowercase canonical (`#f051d5` not `#F051D5` — Figma normalizes but DESIGN.md uses uppercase; align to DESIGN.md). Numbers exact (`16` not `15.999`).

### F3. Binding mandatory
Every fill, stroke, corner radius, padding on generated nodes must be Variable-bound, not raw value. Use `figma_bind_token` API. Manual raw value = regression. Verify via `figma_get_node` post-creation: each property has `boundVariables` field populated.

### F4. State coverage complete
For each Component § pushed, verify all canonical states present (table above). Missing state = regression. Add via `figma_create_node` as new Variant.

### F5. 85/10/5 law visual estimate
After full sync, call `figma_get_screenshot` on the main documentation page. Visual review (or AI-via-screenshot): does Magenta appear ≤ 5% of surface area? If > → flag layout issue (likely too many CTA buttons in documentation, not a real product page).

### F6. WCAG AA contrast for component artboards
For each Button / Card / Input artboard, verify text-on-surface contrast ≥ 4.5:1 (body) or 3:1 (large text). Figma Console MCP has accessibility linting — invoke if available.

### F7. Component name registry check (Posture #8)
Every Component created must correspond to a § 3 entry. New name (`PillarCard`, `HeroSpot`) not in § 3 → gap candidate (component-level), propose 3 paths.

### F8. Cross-target consistency (Posture #9)
If HTML or React version of same component exists (vault or repo), diff Variable values vs CSS variable values. Drift between Figma Variable `color/magenta/500 = #F051D5` and CSS `--magenta-500: #FF005C` = error. Single source of truth (DESIGN.md) MUST resolve drift.

## Anti-patterns specific to Figma target

1. **Pushing without `figma_get_status` check.** Connection may report initialized: false on cloud mode session drops. Pushing into a dead connection produces silent failures. ALWAYS verify first.

2. **Skipping snapshot before destructive update.** User loses history irreversibly. Default: ask. Override only with explicit `--no-snapshot` flag.

3. **Creating standalone (unbinned) nodes with raw values.** Every generated node is Variable-bound or it doesn't ship.

4. **Manual Component variants instead of Variant properties.** Use Figma's Variant property system (`state` enum, `size` enum) rather than duplicating component frames flat. Allows designer to swap variant in-place.

5. **Forgetting documentation pages on full sync.** Color Palette, Typography, Spacing & Radii pages are part of the sync contract — they make the design system discoverable for human designers using the file.

6. **Cloud mode for production sync.** Cloud mode has 3 hops (plugin → relay → MCP → Claude), session drops, 5-min pairing code expiry. Local mode (1 hop) is recommended. If user is forced cloud → surface known issues and offer to retry on local.

7. **Naming Variables in flat style (`magenta500`).** Use slash namespace (`color/magenta/500`) — Figma native folder display.

8. **Bypassing visual git on `--fresh` workflow.** If user requests fresh snapshot, never overwrite the previous one — always create new page with date-stamped name.

## Hand-off output format — Figma

```
✅ Figma sync complete (target: Figma)
- File: [Figma file URL]
- Page: [page name]
- Compliance: strict Amaca DS v[X.Y.Z]
- Operations applied:
  - Variables: N created, N updated, N skipped (unchanged)
  - Components: N created, N updated with state coverage [list states]
  - Documentation pages: [Color Palette | Typography | Spacing | Radii] generated
- Snapshot preserved: [snapshot page name | none]
- Verification screenshots: N captured via figma_get_screenshot

Optional next actions:
- Designer review in Figma Desktop
- Run `figma_lint_accessibility` if available
- Diff vs previous snapshot to confirm intended changes
- Update amaca.design site if Figma is the showcase source
```

## Cross-references

- [[_Skills/amaca-frontend/SKILL.md]] — parent skill
- [[_Crafting/Amaca/DESIGN.md]] § 2 Tokens — source of truth for Variable values
- [[_Crafting/Amaca/DESIGN.md]] § 3 Components — canonical specs to push
- [[_Crafting/Amaca/DESIGN.md]] § 6.2 Focus visibility — state coverage requirements
- [[_Crafting/Amaca/DESIGN.md]] § 13 Multi-deploy compatibility (v2.5.0+) — naming convention
- [[_Skills/amaca-frontend/HTML.md]] — sibling target reference
- [[_Skills/amaca-frontend/REACT.md]] — sibling target reference
- [[2026-05-25 - Prior art lifesized + decisione Tailwind v4 nativo]] — decision doc + lifesized pattern extraction
- Figma Console MCP docs: https://docs.figma-console-mcp.southleft.com/
- Figma Console MCP repo: https://github.com/southleft/figma-console-mcp
- lifesized prior art: https://github.com/lifesized/figma-design-sync
- Figma Dev Mode MCP (read-only, official): https://www.figma.com/blog/introducing-figma-mcp-server/
