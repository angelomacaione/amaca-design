# Amaca — AGENTS.md (universal agent rules)
**For** Codex · Cursor · Copilot · Windsurf · Amp · Devin · Aider · Zed · Jules · VS Code · JetBrains Junie (the AGENTS.md standard).
**Where it goes** `AGENTS.md` at your repo root (nested files allowed for sub-areas).
**Use** Agents load it automatically; it carries the token discipline, the laws, the a11y floor, a ## Verify checklist.
**Verify** Ask for UI: tokens by name, 85/10/5 held, no raw hex/px.
**In this bundle** AGENTS.md · tokens.css (full tables) · DESIGN.md (full spec).

— Amaca · MIT · https://amaca.design
