# Amaca — AGENTS.md

The open agent-rules file: Codex, Copilot, Cursor and Devin read it at the repo root.

## How to install

1. No AGENTS.md yet: put it at the repo root. Already have one: paste Amaca's under its own `## Amaca` heading; the nearest AGENTS.md to a file wins, so a copy in a subfolder covers only that folder.
2. **Aider**: add `read: AGENTS.md` to `.aider.conf.yml`. **Claude Code** does not read AGENTS.md: use the Claude bundle, or `@AGENTS.md` in your CLAUDE.md.
3. Keep `DESIGN.md` and `tokens.css` beside it.

## What's inside

- `AGENTS.md`
- `DESIGN.md`
- `tokens.css`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
