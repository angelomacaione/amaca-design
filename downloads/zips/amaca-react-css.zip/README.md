# Amaca — React / CSS (raw variables)
**Use** Import tokens.css (vars + reset) then components.css; reference var(--token) and the canonical classes (.btn-primary, .card, .field).
**Verify** No raw hex/px in component CSS (grep #[0-9A-Fa-f]{3,8} / [0-9]+px).
**In this bundle** tokens.css · components.css.

— Amaca · MIT · https://amaca.design
