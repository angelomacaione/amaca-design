# Amaca — Raw CSS variables

tokens.css (variables and reset) and components.css: var(--token) everywhere, no build step.

## How to install

1. Load `tokens.css` first, then `components.css`.
2. Write the canonical classes (`.btn-primary`, `.card`, `.field`) and `var(--token)` for every value.

## What's inside

- `tokens.css`
- `components.css`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
