# Amaca — Google design.md (Stitch)
**For** Google Stitch and any agent that consumes the Google Labs design.md standard.
**Use** On Stitch's *Start with your project* screen, paste DESIGN.md into the *existing DESIGN.md* box (or upload it). Pick Stitch's most capable model for brand fidelity.
**Verify** Lints clean against design.md (0 findings, colors.primary present).
**In this bundle** DESIGN.md.

— Amaca · MIT · https://amaca.design
