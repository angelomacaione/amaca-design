# Amaca — Google design.md

The spec in the Google Labs design.md standard, for Stitch and any agent that reads it.

## How to install

1. In your Stitch project, import `DESIGN.md` as the project's design rules.
2. Needs a frontier-tier model: on a lighter one the spec is read as context, not as instructions (§ 03.3).

## What's inside

- `DESIGN.md`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
