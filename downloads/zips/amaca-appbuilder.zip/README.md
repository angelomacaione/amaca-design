# Amaca — App builders (paste-in)
**For** Figma Make, v0, Lovable, Base44, Bolt — app builders with no filesystem.
**Use** Paste AI-INSTRUCTIONS.md into the builder’s instructions / knowledge box. Keep the prompt brand-neutral (describe the screen, not a mood); let the tokens carry the look.
**Verify** Generated UI uses the magenta primary only on the CTA, obsidian everywhere else.
**In this bundle** AI-INSTRUCTIONS.md.
**Shared source** Same paste-in as the AI chat bundle (amaca-chat.zip) — both baked from AI-INSTRUCTIONS.md via build-paste-in-bundles.sh. Edit the source once; rebuild both.

— Amaca · MIT · https://amaca.design
