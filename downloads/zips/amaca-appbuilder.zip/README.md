# Amaca — v0 · Lovable · Base44 · Bolt

The same paste-in, for builders with no filesystem of yours.

## How to install

1. Paste `AI-INSTRUCTIONS.md` into the builder's instructions or knowledge.
2. Where it takes files, add `theme.css` from the Tailwind bundle as the project's foundation.
3. Describe the screen, not a mood: the tokens carry the look.
4. Needs a frontier-tier model: on a lighter one the spec is read as context, not as instructions (§ 03.3).

## What's inside

- `AI-INSTRUCTIONS.md`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
