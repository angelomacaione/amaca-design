# Amaca — Claude (skill + Claude Code)

Two ways to use Amaca with Claude, in one bundle:

## Claude app / Cowork
Install **`amaca-frontend.skill`** via Settings -> Capabilities -> Skills. It is self-contained (tokens + spec bundled inside) -- you install it, you don't unzip it. Then say "build with Amaca ..." and it generates token-only, on-brand UI.

## Claude Code
Drop the contents of **`claude-code/`** into your project:
- `CLAUDE.md` -> your repo root (it can `@import DESIGN.md`)
- `DESIGN.md` -> the full spec it reads
- `tokens.css` -> so the `var(--token)` references actually resolve

## Verify
Ask for a primary button: it uses `var(--magenta-500)`, the dual-ring focus, and zero raw hex.

-- Amaca - MIT - https://amaca.design
