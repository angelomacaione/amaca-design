# Amaca — Claude (skill + CLAUDE.md)
**For** Claude (Cowork, Claude Code) and Anthropic-stack runtimes.
**Install** amaca-frontend.skill via Settings → Capabilities → Skills; drop CLAUDE.md at repo root (it can @import DESIGN.md).
**Use** "build with Amaca …" → token-only output.
**Verify** Ask for a primary button: var(--magenta-500), dual-ring focus, no raw hex.
**In this bundle** CLAUDE.md · amaca-frontend.skill · tokens.css · DESIGN.md.

— Amaca · MIT · https://amaca.design
