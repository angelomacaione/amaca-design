# Amaca — Claude — skill + amaca.md

The rules as a Claude skill, tokens bundled, and amaca.md for Claude Code.

## How to install

1. **Claude app or desktop**: Customize → Skills → + → Create skill → Upload a skill, and choose `amaca-frontend.zip`. Code execution must be on (Settings → Capabilities).
2. **Claude Code**: copy `claude-code/amaca.md` into `.claude/rules/`; it loads when Claude works on UI files. Or add `@amaca.md` to your own CLAUDE.md.
3. Keep `DESIGN.md` and `tokens.css` in the repo. Do not import DESIGN.md: it is read a section at a time.

## What's inside

- `amaca-frontend.zip`
- `claude-code/amaca.md`
- `claude-code/DESIGN.md`
- `claude-code/tokens.css`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
