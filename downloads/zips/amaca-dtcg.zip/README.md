# Amaca — DTCG pipeline

Every token as W3C DTCG JSON, with what each one is for, for Style Dictionary, Tokens Studio and any DTCG build.

## How to install

1. Feed `tokens.dtcg.json` to your token build and transform to any target.
2. Gradients, fluid type and em tracking carry their CSS in `$extensions.amaca` or as a CSS string: DTCG cannot hold them.

## What's inside

- `tokens.dtcg.json`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
