# Amaca — DTCG pipeline
**For** Style Dictionary, Tokens Studio, any DTCG-aware build.
**Use** Feed tokens.dtcg.json into your token build; transform to any target from one source.
**Verify** Parses as valid DTCG; color.magenta.500 = #F051D5.
**In this bundle** tokens.dtcg.json.

— Amaca · MIT · https://amaca.design
