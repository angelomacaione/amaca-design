# Amaca — DTCG tokens
**For** Style Dictionary, Tokens Studio, and any DTCG-aware pipeline.
**Format** W3C DTCG **stable 2025.10**: colors as colorSpace/components objects (hex kept as fallback), dimensions and durations as value+unit objects, easings as cubicBezier arrays, structured shadows, font stacks as arrays. Letter-spacing tokens stay as CSS em strings (stable dimension is px|rem only).
**Use** Feed `tokens.dtcg.json` into your token build; transform to any target (CSS, iOS, Android) from one source.
**Verify** `magenta-500` resolves to sRGB components with `#F051D5` as hex fallback.
