# Amaca — Figma — /amaca-figma skill

In-canvas custom skill: builds with Amaca Variables, audits what landed on canvas, repairs in a verify loop. Fetch-first: it never invents values.

## How to install

1. In a Figma file: prompt box → attachment icon → Skills → Add skill, and upload `amaca-figma.md`.
2. Invoke it with `/amaca-figma`: **build a pricing card**, or **audit this selection**.
3. It reads amaca.design/llms-full.txt before acting and stops if it cannot.

## What's inside

- `amaca-figma.md`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
