# Amaca — Figma agent skill (/amaca-figma)
**For** the Figma agent, in Figma Design and Figma Make (in-canvas custom skill).
**Install** In a Figma file: prompt box → attachment icon → Skills → Add skill → upload `amaca-figma.md`. Invoke with `/amaca-figma`.
**Use** "/amaca-figma build a pricing card" — generates with Amaca Variables, then self-audits in a verify loop (max 2 repair passes). Or "/amaca-figma audit this selection" — lints existing work on canvas evidence; in Figma Make the audit also covers the generated code (JS constants, easing/duration literals, token-layer completeness) and the report declares motion descoping; stat numbers count up on entrance per spec.
**Verify** It fetches https://amaca.design/llms-full.txt before acting and stops if unreachable — it never invents a hex, px, or easing.
**Note** Advisory best-effort (the Figma agent is non-deterministic). The deterministic, build-failing gate ships with the amaca-frontend bundle at https://amaca.design.
