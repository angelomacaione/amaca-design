# Amaca — Tailwind v4 @theme
**Use** `npm install amaca-design`; then in your entry CSS: `@import "tailwindcss";` `@import "amaca-design/theme.css";` (it brings tokens.css). Write utilities (bg-primary-500, p-4, rounded-lg).
**Verify** `npm run build`: utilities resolve to canonical hex; a typo (bg-primary-550) produces nothing.
**In this bundle** theme.css · tokens.css.

— Amaca · MIT · https://amaca.design
