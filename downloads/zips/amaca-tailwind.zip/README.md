# Amaca — Tailwind v4 @theme

Every token as a @theme block: bg-primary-500, p-4, rounded-lg.

## How to install

1. `npm install amaca-design`, or copy both files into your styles.
2. In your entry CSS: `@import "tailwindcss";` then `@import "amaca-design/theme.css";`, which brings tokens.css.
3. A typo such as `bg-primary-550` produces nothing: the scale is closed.

## What's inside

- `theme.css`
- `tokens.css`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
