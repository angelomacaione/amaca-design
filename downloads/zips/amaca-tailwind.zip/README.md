# Amaca — Tailwind v4 @theme
**Use** `npm install github:angelomacaione/amaca-design`; then in your entry CSS: `@import "tailwindcss";` `@import "amaca-design/styles/theme.css";`. Write utilities (bg-magenta-500, p-4, rounded-lg).
**Verify** `npm run build`: utilities resolve to canonical hex; a typo (bg-magenta-550) produces nothing.
**In this bundle** theme.css · tokens.css.

— Amaca · MIT · https://amaca.design
