# Amaca — Agent Plugin

One package, two manifests, one skill. The `amaca-frontend` skill installs on
Claude Code through `.claude-plugin/plugin.json`, and on every Agent Plugins 1.0
client — Cursor, OpenAI Codex, GitHub Copilot, VS Code, Kiro — through the
`plugin.json` at the root. Same file, no rewrites.

## Install

**Claude Code** — add this repo as a plugin marketplace, then install:

    /plugin marketplace add angelomacaione/amaca-design
    /plugin install amaca-design@amaca

**Agent Plugins 1.0 clients** — install from your client's plugin UI or catalog,
pointing at this package.

**By hand, anywhere** — unpack `skills/amaca-frontend/` into the skills path your
tool reads: `.agents/skills/` (vendor-neutral, read by Cursor 2.4+ and Codex),
`.claude/skills/`, or `.cursor/skills/`.

## Then

    build a pricing card with Amaca

The skill reads `DESIGN.md` first, every time, and generates token-only output —
`var(--magenta-500)`, never a raw hex. It self-audits before handing back.

## What's inside

    plugin.json                  Agent Plugins 1.0 manifest
    .claude-plugin/plugin.json   Claude Code manifest
    skills/amaca-frontend/       the skill: SKILL.md + DESIGN.md + HTML/REACT/FIGMA.md + tokens

The spec lives inside the skill, in one copy. On conflict with the published
repo, the repo wins — the bundled copy is a frozen offline fallback and the
version pin.

— Amaca · MIT · https://amaca.design
