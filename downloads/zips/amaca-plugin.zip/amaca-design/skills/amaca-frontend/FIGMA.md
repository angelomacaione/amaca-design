---
type: skill-reference-doc
parent_skill: amaca-frontend
target: Figma
version: 1.2
created: 2026-05-25
tags:
  - skill-reference
  - amaca
  - figma
  - figma-console-mcp
---

# Figma target — reference doc for amaca-frontend

> Conventions, patterns, and verification checks specific to **Figma push** target. Read by `amaca-frontend` SKILL.md Step 4 when target = Figma. Adapted from prior art `lifesized/figma-design-sync` (MIT) — pattern reuse with Amaca-specific posture overlay. Does not stand alone — requires the parent SKILL.md, DESIGN.md as canonical context, and Figma Console MCP installed.

## When this target applies

- Push DESIGN.md tokens → Figma Variables (color, number, dimension, string, timing, easing)
- Create or update Component artboards in Figma (Button states, Card variants, Inputs, etc.)
- Generate documentation pages in Figma file (Color Palette, Typography, Spacing & Radii, Components)
- Audit existing Figma file against DESIGN.md (drift detection, dry-run report)
- Sync component state coverage (default / hover / focus / active / disabled / loading) per the Components specs

If the user wants HTML/React code → switch to corresponding target. If the user wants new design exploration (not push from DESIGN.md) → decline + suggest designing in Figma natively first, then sync via this skill.

## Prerequisites

1. **Figma Console MCP installed and connected**:
   ```bash
   claude mcp add figma-console -s user -e FIGMA_ACCESS_TOKEN=figd_YOUR_TOKEN -- npx -y figma-console-mcp@latest
   ```
2. **Figma access token** from Figma Desktop → Settings → Security (starts with `figd_`)
3. **Desktop Bridge plugin** installed and running in Figma Desktop. Auto-connects via WebSocket localhost:9223 (local mode, recommended).
4. **Target Figma file open** in Figma Desktop on the page where push will land.

Verify connection at Step 4 entry: call `figma_get_status` (or equivalent first-call discovery) — if `initialized: false`, surface to user and STOP. Do not proceed with API calls that will fail silently.

## Figma Console MCP tools — subset used

Figma Console MCP exposes 59+ tools. The amaca-frontend Figma target uses a subset:

| Tool | Purpose |
|---|---|
| `figma_get_status` | Verify connection initialized |
| `figma_get_variables` | Read existing Variables in file (audit, drift detection) |
| `figma_create_variable` | Create a Color/Number/Dimension Variable |
| `figma_update_variable` | Update existing Variable value |
| `figma_create_node` | Create frame, rectangle, text node, group |
| `figma_bind_token` | Bind a node property (fill, stroke, padding) to a Variable |
| `figma_create_component` | Create reusable Component from a frame |
| `figma_get_screenshot` | Capture frame as image (verification) |
| `figma_execute` | Arbitrary Plugin API JavaScript (escape hatch for complex operations) |

For full tool registry, reference: https://docs.figma-console-mcp.southleft.com/

## Code-first push pattern (canonical for Amaca)

DESIGN.md is single source of truth. Figma is projection. Direction: code → Figma, NEVER Figma → code (unless explicit audit request).

### Token name mapping — DESIGN.md → Figma Variable

| DESIGN.md token | Figma Variable name | Type | Mode |
|---|---|---|---|
| `--primary-500` | `color/primary/500` | Color | Default |
| `--obsidian-800` | `color/obsidian/800` | Color | Default |
| `--success` | `color/semantic/success` | Color | Default |
| `--s-4` | `spacing/4` | Number (16) | Default |
| `--r-lg` | `radius/lg` | Number (12) | Default |
| `--t-body` | `typography/body/size` | Number (15) | Default |
| `--lh-normal` | `typography/lineHeight/normal` | Number (1.45) | Default |
| `--d-quick` | `motion/duration/quick` | Timing (200ms) — Number where Timing is unavailable | Default |
| `--d-*` (all six) | `motion/duration/*` | Timing (ms) — Number fallback | Default |
| `--ease-standard` | `motion/easing/standard` | Easing — cubic-bezier(0.22, 1, 0.36, 1) | Default |
| `--ease-accel` | `motion/easing/accel` | Easing — cubic-bezier(0.7, 0, 0.84, 0) | Default |
| `--ease-decel` | `motion/easing/decel` | Easing — cubic-bezier(0.16, 1, 0.3, 1) · signature | Default |
| `--ease-spring` | `motion/easing/spring` | Easing — cubic-bezier(0.34, 1.56, 0.64, 1) · spatial props only | Default |

**Motion variables (v1.1)**: Figma Variables support dedicated **Timing** and **Easing** types — Timing binds to a preset animation's delay/duration and Easing to animation presets/keyframes in Figma Motion. Push the `--d-*` scale as Timing variables and the four curves as Easing variables where the file/plan supports them; fall back to Number (ms) for durations otherwise, and migrate Number → Timing when the file is next touched. In classic prototyping interactions these variables are not bindable — annotate the pair on the component instead.

**Convention**: slash-separated namespace mirrors DESIGN.md token hierarchy. Figma displays nested with `/` as folder separator natively. If v2.5.0+ Tailwind v4 namespaced names (`--color-primary-500`) are in shared.css, strip the redundant prefix in Figma name (`color/primary/500` not `color/color/primary/500`).

### State coverage for components

Required states are **the component's rows in the § 3.0.1 state index** (Components). Read them there, per component, at push time. The index is the closed list; this file does not restate it, because the copy that used to live here drifted: it listed `active` and `loading` on Button and `hover · focus · filled` on Input, none of which the index carries, and a generator following it built Variants the contract does not have.

Three readings that decide most pushes:

- A Variant property value outside the closed state vocabulary is off-system (F4).
- `focus-visible` is mandatory for anything focusable; `error` is mandatory for every form control.
- Where the index has no row for a component, its own section is the source (Card hover lives in § Card). Loader and Chat message ship **variants** from their sections (spinner · skeleton · progress; sent · received · pending · failed) — those are not states and do not go on the `state` property.

Pattern: each state is a separate Variant within the Figma Component, with property `state=hover` (etc.) bound to Variant property.

### Slash commands convention (inspired by lifesized prior art)

When user issues high-level Figma intent, map to canonical sub-actions:

- **"sync Amaca to Figma"** or **"push DESIGN.md to Figma"** → full sync: tokens + all Components components
- **"push tokens only"** → Variables only, skip Component artboards
- **"sync component Button"** or **"push Button to Figma"** → single component with all variants
- **"audit Figma vs DESIGN.md"** → READ Figma Variables, diff against DESIGN.md, output dry-run report
- **"snapshot Figma current page"** → visual git pattern: clone current page as `[date] - vX.Y.Z snapshot` before destructive sync

### Visual git pattern

Before any destructive sync (modifying existing Variables or Components), offer the user a snapshot:

```
⚠️ Sync will modify existing Variables in this Figma page.
Recommend snapshot first?
(a) Yes — clone page as "2026-05-25 - Pre-sync snapshot" (preserves history)
(b) No — proceed with in-place update
(c) Cancel
```

Implementation: use `figma_execute` to duplicate the current page programmatically before applying changes.

## Workflow inside Step 4 (Figma-specific)

After reading FIGMA.md (this file), proceed:

1. **Verify connection**: `figma_get_status` → confirm `initialized: true`. If not, STOP and surface to user.
2. **Identify scope**: full sync / tokens only / single component / audit. Confirm with user if ambiguous.
3. **Pre-flight diff**: call `figma_get_variables`. Diff against DESIGN.md the token sections. Identify create / update / delete operations.
4. **Snapshot offer** (if destructive): visual git pattern above.
5. **Apply operations in order**:
   a. Create/update Color Variables (Obsidian + Magenta + Supporting + Semantic)
   b. Create/update Number Variables (Spacing + Radius + Typography size) and Timing/Easing Variables (Motion duration + easing; Number fallback for durations where Timing is unavailable)
   c. Create/update Component artboards (one per Components entry) with state variants
   d. Bind nodes to Variables (every fill, stroke, corner radius, padding token-bound)
6. **Generate documentation pages** (if full sync):
   - Color Palette page with swatch grid (one rect per Color Variable, label below)
   - Typography page with type scale samples in Satoshi
   - Spacing & Radii page with visual samples
7. **Verification screenshots**: `figma_get_screenshot` on each generated artboard. Visual evidence of compliance.

## Verification checks — Figma-specific

In addition to baseline checks (SKILL.md § Posture 6):

### F1. Variable name canonical
Every Variable created must follow slash-namespace convention (`color/primary/500`). Drift = surface (e.g., user previously created `magenta500` flat name → propose rename via `figma_update_variable`).

### F2. Token value exact match
Every Variable value must match DESIGN.md the token sections byte-for-byte. Hex colors lowercase canonical (`#f051d5` not `#F051D5` — Figma normalizes but DESIGN.md uses uppercase; align to DESIGN.md). Numbers exact (`16` not `15.999`).

### F3. Binding mandatory
Every fill, stroke, corner radius, padding on generated nodes must be Variable-bound, not raw value. Use `figma_bind_token` API. Manual raw value = regression. Verify via `figma_get_node` post-creation: each property has `boundVariables` field populated.

### F4. State coverage complete
For each Component § pushed, verify every state the § 3.0.1 index lists for it is present (see State coverage above). Missing state = regression. Add via `figma_create_node` as new Variant. **The state list is closed (Components › § 3.0.1)**: Variants map to the closed state vocabulary as § 3.0.1 states it — read the list there, never from this file — and to nothing else. A `focus-visible` Variant is mandatory for anything focusable; an `error` Variant is mandatory for every form control. Variant property values that aren't in the vocabulary are off-system.

### F5. 85/10/5 law visual estimate
After full sync, call `figma_get_screenshot` on the main documentation page. Visual review (or AI-via-screenshot): does Magenta appear ≤ 5% of surface area? If > → flag layout issue (likely too many CTA buttons in documentation, not a real product page).

### F6. WCAG AA contrast for component artboards
For each Button / Card / Input artboard, verify text-on-surface contrast ≥ 4.5:1 (body) or 3:1 (large text). Figma Console MCP has accessibility linting — invoke if available.

### F7. Component name registry check (Posture #8)
Every Component created must correspond to a row in the **§ 3.0 component registry** — the closed inventory. A name not in it (`PillarCard`, `HeroSpot`) is `off-system`: stop and propose the 3 paths, don't publish it. `css-only` rows may be reproduced as-is and never extended with new Variants; `site-only` rows are documentation chrome and are never published to the library.

### F8. Cross-target consistency (Posture #9)
If HTML or React version of same component exists (vault or repo), diff Variable values vs CSS variable values. Drift between Figma Variable `color/primary/500 = #F051D5` and CSS `--primary-500: #FF005C` = error. Single source of truth (DESIGN.md) MUST resolve drift.

### F9. Stat count-up (RIGID)
Stat/KPI components carry the count-up contract — `--d-draw` · `--ease-decel`, composing from zero and landing exactly on the target; reduced motion lands instantly. On canvas this is an annotation + variant contract (the canvas cannot execute it): the stat component's description names the pair so downstream code generation implements it. Missing annotation where a stat component ships = warning.

### F10. Spring-on-effect
Any `motion/easing/spring` (or overshoot curve) bound or annotated on an *effect* property — fill/color, opacity, shadow — is a finding: spring easing rides spatial properties only (spec § Motion RIGID). Per-component pairs come from the spec's motion index (`DESIGN.md → Motion`); an annotation that contradicts its component's row is a finding.

## Anti-patterns specific to Figma target

1. **Pushing without `figma_get_status` check.** Connection may report initialized: false on cloud mode session drops. Pushing into a dead connection produces silent failures. ALWAYS verify first.

2. **Skipping snapshot before destructive update.** User loses history irreversibly. Default: ask. Override only with explicit `--no-snapshot` flag.

3. **Creating standalone (unbinned) nodes with raw values.** Every generated node is Variable-bound or it doesn't ship.

4. **Manual Component variants instead of Variant properties.** Use Figma's Variant property system (`state` enum, `size` enum) rather than duplicating component frames flat. Allows designer to swap variant in-place.

5. **Forgetting documentation pages on full sync.** Color Palette, Typography, Spacing & Radii pages are part of the sync contract — they make the design system discoverable for human designers using the file.

6. **Cloud mode for production sync.** Cloud mode has 3 hops (plugin → relay → MCP → Claude), session drops, 5-min pairing code expiry. Local mode (1 hop) is recommended. If user is forced cloud → surface known issues and offer to retry on local.

7. **Naming Variables in flat style (`magenta500`).** Use slash namespace (`color/primary/500`) — Figma native folder display.

8. **Bypassing visual git on `--fresh` workflow.** If user requests fresh snapshot, never overwrite the previous one — always create new page with date-stamped name.

## Hand-off output format — Figma

```
✅ Figma sync complete (target: Figma)
- File: [Figma file URL]
- Page: [page name]
- Compliance: strict Amaca DS v[X.Y.Z]
- Operations applied:
  - Variables: N created, N updated, N skipped (unchanged)
  - Components: N created, N updated with state coverage [list states]
  - Documentation pages: [Color Palette | Typography | Spacing | Radii] generated
- Snapshot preserved: [snapshot page name | none]
- Verification screenshots: N captured via figma_get_screenshot

Optional next actions:
- Designer review in Figma Desktop
- Run `figma_lint_accessibility` if available
- Diff vs previous snapshot to confirm intended changes
- Update amaca.design site if Figma is the showcase source
```

## Cross-references

- [[SKILL.md]] — parent skill
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) the token sections — source of truth for Variable values
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Components — canonical specs to push
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Accessibility › Focus visibility — state coverage requirements
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Multi-deploy compatibility (v2.5.0+) — naming convention
- [[HTML.md]] — sibling target reference
- [[REACT.md]] — sibling target reference
- [[2026-05-25 - Prior art lifesized + decisione Tailwind v4 nativo]] — decision doc + lifesized pattern extraction
- Figma Console MCP docs: https://docs.figma-console-mcp.southleft.com/
- Figma Console MCP repo: https://github.com/southleft/figma-console-mcp
- lifesized prior art: https://github.com/lifesized/figma-design-sync
- Figma Dev Mode MCP (read-only, official): https://www.figma.com/blog/introducing-figma-mcp-server/
