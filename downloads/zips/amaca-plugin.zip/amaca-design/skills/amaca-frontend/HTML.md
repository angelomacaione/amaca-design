---
type: skill-reference-doc
parent_skill: amaca-frontend
target: HTML
version: 1.0
created: 2026-05-25
tags:
  - skill-reference
  - amaca
  - html
---

# HTML target — reference doc for amaca-frontend

> Conventions, patterns, and verification checks specific to **vanilla HTML/CSS/JS** target. The executable form of these checks ships in the bundle as `scripts/verify-output.py` — Step 6 of SKILL.md runs it as a RIGID gate; this document remains the reasoning behind each check and covers what the script cannot see (rendered geometry, contrast, 85/10/5 by area). Read by `amaca-frontend` SKILL.md Step 4 when target = HTML. Does not stand alone — requires the parent SKILL.md and DESIGN.md as canonical context.

## When this target applies

- Stand-alone HTML/CSS/JS prototype (slide deck, landing, single-page demo)
- Self-contained `.html` file with `<style>` inline or separate `tokens.css` + `components.css`
- Static export for Cowork artifact or Vercel hosting
- No build step required (no Vite, no Webpack, no Tailwind compile)

If the user wants utility classes auto-generated → switch to React target (Tailwind v4 build pipeline). If the user wants Figma push → switch to Figma target.

## Token reference syntax — HTML

All tokens referenced via CSS variable syntax: `var(--token-name)`.

Pattern:
```css
.login-card {
  background: var(--obsidian-800);
  border: 1px solid var(--obsidian-700);
  border-radius: var(--r-lg);
  padding: var(--s-8);
  transition: transform var(--d-quick) var(--ease-standard);
}
```

**Note v2.4.0+ compatibility**: if shared.css migrated to `@theme` block with namespaced tokens (`--color-primary-500` instead of `--primary-500`), HTML target supports BOTH naming conventions during transition. Tailwind v4 `@theme` block still exposes the variables at `:root` via runtime CSS variables. Reference DESIGN.md Multi-deploy compatibility for canonical naming. If both exist, prefer namespaced version for forward compatibility.

## File layout convention

For multi-file projects:
```
project/
├── styles/
│   ├── tokens.css       # mirror of repo tokens.css (or @theme block if v2.4.0+)
│   └── components.css   # all .btn-*, .card, .field, etc.
└── index.html           # imports both via <link rel="stylesheet">
```

For single-file artifacts (Cowork output):
- Inline `<style>` block in `<head>` with tokens + components
- Inline `<script>` at end of `<body>` for JS (IIFE pattern to avoid global pollution)
- All `<link rel="preconnect">` for Satoshi CDN (Fontshare) before stylesheet load

## Code conventions — reproduced patterns

### Replay pattern (re-trigger CSS animation)

Canonical reproduction from DESIGN.md Code conventions › JavaScript:
```js
function replayAnimation(el) {
  el.classList.remove('is-in');
  void getComputedStyle(el).opacity;  // force reflow
  setTimeout(() => el.classList.add('is-in'), 50);
}
```

### Staggered text reveals (IntersectionObserver)

```js
const reveal = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-in');
      reveal.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('[data-reveal]').forEach(el => reveal.observe(el));
```

CSS for staggered children:
```css
[data-reveal] > * {
  opacity: 0;
  transform: translateY(8px);
  transition: opacity var(--d-base) var(--ease-decel), transform var(--d-base) var(--ease-decel);
}
[data-reveal].is-in > *:nth-child(1) { transition-delay: 0s;                           opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(2) { transition-delay: var(--d-instant);             opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(3) { transition-delay: calc(2 * var(--d-instant));   opacity: 1; transform: translateY(0); }
[data-reveal].is-in > *:nth-child(4) { transition-delay: calc(3 * var(--d-instant));   opacity: 1; transform: translateY(0); }
```

### Anchor-link routing (multi-page single-file)

```js
function goToSlide(num) {
  const id = `slide-${num}`;
  history.replaceState(null, '', `#${id}`);  // no history pollution
  document.getElementById(id).scrollIntoView({ behavior: 'instant' });
}
window.addEventListener('hashchange', () => {
  const id = location.hash.slice(1);
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
});
```

### SVG transforms canonical

Transform SVG groups via SVG attribute, not CSS, for sub-pixel precision:
```html
<g transform="translate(0,0) scale(1) rotate(0)" data-anim="reveal">
  <!-- children -->
</g>
```

CSS animation drives `data-anim` state, JS reads-and-writes `transform` attribute.

## Motion pairing & Spatial vs Effects (RIGID)

The trigger decides the pairing: user-triggered states (hover, press, focus) ride `var(--d-quick) var(--ease-standard)`; system-triggered transitions (content entering, leaving, or moving without a direct pointer cause) ride `var(--d-base) var(--ease-decel)`.

Every animated property has a type, and the type gates the easing. **Spatial** properties — `transform` (translate, rotate, scale), position, size, shape — may use any easing, including `--ease-spring`. **Effect** properties — `color`, `background`, `opacity`, `box-shadow`, `border-color` — use no-overshoot curves only; `--ease-spring` on an effect property is off-system.

Per-component pairs are ratified in the spec's motion index (`DESIGN.md → Motion`): read the component's rows before animating it. A component with no rows follows the default pairing above. Continuous loops (spinner, shimmer, caret) run on per-component clocks outside the duration scale — pending ratification as a motion class.

## Embedded hosts — restate the body unlayered

**Since DESIGN.md v5.3.0** the base layer of `tokens.css` says the body's text again on the body's children (`:where(body > *)`), so a host's unlayered `body{color;font}` stops at the body. What follows stays as the second defence, for text placed straight in `body`.

The base rules of `tokens.css` sit in `@layer base` (DESIGN.md Code conventions › CSS). A host that wraps the page in its own reset — a sandboxed preview, a CMS theme, a documentation shell — writes that reset outside any layer, and an unlayered rule beats every layered one. The `body` takes the host's colour, and every element that inherits it follows: headings first, since no component colours them. Measured: a landing published inside such a host showed its `h1`–`h3` in the host's dark text on `--obsidian-950`.

When the output runs inside a host, restate the `body` declarations in the page's own `<style>`, unlayered and by token:

```css
body {
  color: var(--obsidian-100);
  background: var(--obsidian-950);
  font-family: var(--font-sans);
  font-size: var(--t-body);
  line-height: var(--lh-normal);
}
```

Never unlayer the pasted `tokens.css` to get the same effect: under Tailwind it erases the utilities again (check 32 in the repo).

## Reduced-motion fallback (mandatory)

Global override in `tokens.css` (or inline `<style>`):
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

For specific components with complex orchestration:
```css
@media (prefers-reduced-motion: reduce) {
  .hero-reveal { transition: none; transform: none; }
  .stagger-children > * { transition-delay: 0ms; }
}
```

## Stat count-up (RIGID)

Numeric stats and KPI values compose incrementally on entrance — count up from zero to the target, riding `--d-draw` with `--ease-decel`, landing exactly on the final value (the amaca.design counter pattern). A static stat number where a count-up belongs is off-system.

```js
const rm = matchMedia('(prefers-reduced-motion: reduce)').matches;
function countTo(el){
  const target = parseFloat(el.dataset.countTo);
  if (rm) { el.textContent = String(target); return; }   // reduced motion: land instantly
  const d = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--d-draw')); // token off :root
  const t0 = performance.now();
  const ease = t => 1 - Math.pow(1 - t, 3); // approximates --ease-decel; or use Motion One with the token curve
  (function tick(now){
    const t = Math.min((now - t0) / d, 1);
    el.textContent = String(Math.round(target * ease(t)));
    if (t < 1) requestAnimationFrame(tick); else el.textContent = String(target);
  })(t0);
}
```

Counters MUST land on the exact final value (`onComplete` writes the target). Never hand-copy the duration or curve — read them off `:root`.

## The page's own conduct (v5.3.0)

What the system's own site got wrong in its 5.3.0 cycle, so a generated page does not. DESIGN.md Code conventions › *The site's own conduct* is the source; these are its HTML consequences.

- **A library the page needs to draw ships with the page.** Motion, Mermaid, a chart library: vendor the file beside the page (`vendor/motion-11.15.0.js`, pinned, a classic `<script src>`), never a CDN alone. On a network that blocks the CDN, or a page opened from disk, a CDN-only page shows empty charts and blank diagrams. If something must come from the network, the content's final state shows without it. Fonts are the one exception the Typography section names (Fontshare, with its preconnect, H7). **H12.**
- **Every floating panel rides the top layer.** A menu, a listbox, a date or time picker, a tooltip: make it a manual popover and show it (`el.setAttribute('popover', 'manual'); el.showPopover()`), then place it on its anchor. Prefer CSS anchor positioning (`anchor-name` on the trigger, `position-anchor` and `position-area` with `position-try-fallbacks: flip-block, flip-inline` on the panel): the browser moves it with the page in the same frame; placement by script lags a frame and judders on scroll. Keep a script fallback that flips when it does not fit and stays `--s-2` from the viewport edge. An absolute panel with a z-index is trapped by any card with a transform or `overflow` above it. **H13.**
- **Motion plays when it can be seen.** A chart, a progress bar, a counter starts when its own block is in view (an `IntersectionObserver` on the element, about a third visible), not when the page or its section opens: below the fold it would play unseen and arrive finished. A specimen (an anatomy, a frozen example) never moves.
- **A modal is centred on the viewport's middle.** `left: 50vw; top: 50vh; translate: -50% -50%`, the entrance on `transform: scale(0.96)` → `none`. Centred with `margin: auto`, it slides when the scroll lock hides a classic scrollbar and gives it back on close. Opening and closing a dialog moves nothing behind it.
- **A link inside a demo acts in place.** `href="#"` or a link to the section it sits in gets `preventDefault()`; a Pagination re-draws its own row.
- **A breakpoint the page names is a token** (`--bp-sm`, `--bp-md`, `--bp-lg`), never a number of its own. **An edge of a diagram keeps `--s-4` from every box**: no elbow on a box's line. **A field's value sits in its middle**: a `select` with `appearance: base-select` needs `align-items: center`.
- **Demo content is invented**: never a real person's name, project or employer.

## Verification checks — HTML-specific

In addition to baseline checks (SKILL.md § Posture 6):

### H1. Grep hardcoded values
Regex: `[0-9]+px|#[0-9A-Fa-f]{3,8}|cubic-bezier\(`. Match > 0 = regression (except: SVG stroke-width with explicit `<!-- rationale -->` comment, modal z-index, opacity values, viewport units).

### H2. HTML canonical (Do's and Don'ts › For the AI agent #4)
- Every non-void tag closed explicitly
- Every attribute double-quoted
- No implied closes
- ARIA only when semantic insufficient
- `data-*` for state hooks

### H3. Touch target mandatory (Accessibility #7)
For each clickable element, calculate effective height (height + padding-y). If < 44px and mobile-targetable → warning. Override with explicit rationale comment if intentional (e.g., dense desktop-only UI with 32×32 hit area).

### H4. `.btn-primary` count (Components › Button)
Count occurrences. If > 1 in same screen/page → warning "One per screen" violation. Fix: convert extras to `.btn-secondary` or `.btn-ghost`.

### H5. Focus-visible cross-pressables (Accessibility › Focus visibility)
Every clickable/focusable element must have explicit `:focus-visible` styling. NO reliance on default browser outline. Pattern:
```css
.btn-primary:focus-visible {
  outline: 2px solid var(--obsidian-100);
  outline-offset: 3px;
  box-shadow: var(--ring-halo);  /* § 6.2 pressable halo — a token since v4.2.0 */
}
```

### H6. Replay pattern presence
If component has CSS animation triggered by class toggle, verify Replay pattern is used (force reflow with `getComputedStyle(el).opacity`). Without, second-trigger animation will not replay.

### H7. Preconnect for Satoshi
For pages using Satoshi (DESIGN.md Typography), verify `<link rel="preconnect" href="https://api.fontshare.com">` (or chosen CDN) appears BEFORE stylesheet `<link>`. No `@import` in CSS (blocks rendering).

### H8. Spring-on-effect + raw durations
Grep transitions/animations for `--ease-spring` (or overshoot beziers) applied to color/background/opacity/shadow → finding. Grep raw `[0-9]+ms` durations where a `--d-*` token exists (ratified continuous loops excepted) → finding.

### H9. Component registry lookup (Components › § 3.0)
Before writing a component, look it up in the § 3.0 registry. Every class you emit belongs to a `canonical` row, or is a documented part of one. A class outside the registry is `off-system` — **stop and surface it**, never ship it. `css-only` rows may be used as-is and **never extended** (no new variants, no new modifiers). `site-only` rows are documentation chrome: treat as off-system. This check replaces "does it look like an existing component?" with a table lookup — visual similarity is not coverage (the `.pillar` incident).

### H10. State matrix completeness (Components › § 3.0.1)
For every interactive component you generate, the states you style must come from the closed state vocabulary as § 3.0.1 states it (read the list there — it grows, as `focus` did in v4.0.0 and `selected` in v4.1.0) and must match the § 3.0.1 state index. Two rows are mandatory and their absence is a finding, not a style choice: **`focus-visible` on anything focusable**, **`error` on every form control**. Also verify `z-index`: every value ≥ 10 comes from the seven-layer scale (`--z-sticky` … `--z-max`); a raw one is a finding.

### H11. Body restated for a host
If the output will run inside a host page (a preview sandbox, a CMS, an embed), verify the page's own CSS carries an unlayered `body` rule with `color`, `background` and `font-family` on tokens. Render it inside the host once: a heading in the host's text colour means the rule is missing.

### H12. Nothing the page needs to draw comes from a CDN alone
Every `<script src>` and every `import` from `http(s)://` is a finding, unless the page shows its final state without it (analytics, say). Vendor the file beside the page, pinned. `verify-output.py` check 12.

### H13. A floating panel rides the top layer
A menu, listbox, picker or tooltip that is `position: absolute` with a z-index and is never shown with `showPopover()` (or as a native `popover`) is a finding: a transformed or clipped ancestor will cover or cut it. `verify-output.py` check 13.

## Anti-patterns specific to HTML target

1. **Using `@import` in CSS for fonts.** Always `<link rel="preconnect">` + `<link rel="stylesheet">` in `<head>`. `@import` blocks rendering.

2. **Inline `style="..."` for token values.** Tokens belong in CSS variables, not inline attributes. Exception: dynamic positioning calculated by JS (e.g., `style="--offset: ${px}px"` then CSS reads `var(--offset)`).

3. **`<div onclick>` for actions.** Use `<button>` for actions, `<a>` for nav. Never click handlers on non-interactive elements.

4. **Forgetting to call IIFE wrap on shared.js.** Shared JS file must IIFE-wrap to avoid global namespace pollution:
   ```js
   (function() {
     // shared code
   })();
   ```

## Hand-off output format — HTML

```
✅ Component generated: [name] (target: HTML)
- Compliance: strict Amaca DS v[X.Y.Z]
- Tokens used: N (color), N (spacing), N (radius), N (motion)
- Components: [the relevant Components specs]
- Accessibility: floor 7/7 passed, WCAG AA verified
- Lines: HTML XX / CSS XX / JS XX
- File: [path or "inline single-file"]

Optional next actions:
- Open in browser for visual test
- Run linter (e.g., stylelint, html-validate) if integrated project
- Test reduced-motion: System Preferences → Accessibility → Display → Reduce motion
- Test focus-visible: Tab through interactive elements
```

## Cross-references

- [[SKILL.md]] — parent skill
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Code conventions
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Motion (reduced-motion fallback)
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Accessibility › Focus visibility patterns
- [[REACT.md]] — sibling target reference
- [[FIGMA.md]] — sibling target reference

---

## Accessibility note — primary button label on magenta (WCAG AA + ratified exception)

As of DESIGN.md v2.6.0 the primary CTA carries the system's one ratified exception to the Accessibility floor (Accessibility › Ratified exceptions): `.btn-primary` is near-white `var(--obsidian-050)` on `var(--primary-500)` — ≈ 2.8 : 1 (measured 2.83), below the 4.5 : 1 AA bar — kept on perceptual grounds. As of v2.7.1 the exception is quantified: under APCA (WCAG 3 candidate) the ranking inverts — the light label scores Lc 55.8 vs 47.4 for the dark one; the perceptual model rates near-white as the more readable pairing on this fill. No light color can reach 4.5 : 1 on #F051D5 (pure white tops at 3.07 : 1). Scoped to `.btn-primary`, rest **and** hover bounded to `--primary-500` (no lighten); a compliance-mode dark-label variant exists for AA-contractual contexts (Accessibility › Ratified exceptions) — on request, never default. Precedent already in the system: `::selection` and `.badge-solid` paint near-white on `--primary-500`.

Everywhere else the floor holds — light text on a magenta fill is still a regression on body text, links, and any non-CTA surface. For non-primary text on magenta the AA-passing choice is dark `var(--obsidian-950)` (6.5 : 1); light values fail (`var(--obsidian-100)` = 2.47 : 1; white ≈ 3.07 : 1, large-text only).

Verification (cross-target): `.btn-primary` light-on-primary is expected — do not flag or "fix" to a dark label. Light-on-primary OUTSIDE `.btn-primary` → flag as a floor regression. Added 2026-06-07.
