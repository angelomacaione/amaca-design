# amaca-frontend skill — v1.3.1 (multi-target)

Enforcement skill for generating frontend strict-compliant with the **Amaca Design System**, across three deploy targets: **HTML/CSS/JS**, **React + Tailwind v4**, and **Figma Variables**. It inverts the "vary every time" pattern of standard generation skills — here **convergence is the goal**: the same tokens, components, and motion choreography on every surface.

> Two version lines, on purpose. The **skill** is `v1.3.1`. The **design system** it bundles is `DESIGN.md v5.0.0`. They version independently — a doc fix to the spec doesn't force a skill bump, and vice versa.

## What's in this bundle

- **`SKILL.md`** — the skill: YAML frontmatter + 7-step workflow + posture rules + anti-patterns. Single trigger, single set of posture rules, target-aware from Step 2.
- **`DESIGN.md`** — the canonical design system **v4.1.0**, read as Step 1 mandatory. Bundled in full as an offline fallback + version pin. The **canonical source is the published repo** (`angelomacaione/amaca-design`); the skill reads that and falls back to this copy offline.
- **`tokens.css`** — the raw token layer: every value as a CSS custom property (`:root{ --primary-500:#F051D5 }`). Drop it into your project so the `var(--token)` references the skill generates actually resolve.
- **`theme.css`** — the Tailwind v4 `@theme` projection of the same tokens (`bg-primary-500`, `p-4`, `rounded-lg`).
- **`HTML.md`** — target reference: vanilla HTML/CSS/JS conventions (Replay pattern, IntersectionObserver reveals, anchor-link routing, SVG transforms).
- **`REACT.md`** — target reference: React + Tailwind v4 `@theme` utility classes, CSS-modules fallback, `theme.css` import.
- **`FIGMA.md`** — target reference: Figma Console MCP usage, push Variables, component artboards with state coverage, visual-git snapshots.
- **`README.md`** — this file.

## How target detection works

After Amaca-scope is confirmed, the skill picks a target in Step 2:

- **HTML** — single/multi-file prototype, landing, slide deck.
- **React** — component with Tailwind v4 utilities (or CSS-modules fallback) in a real project repo.
- **Figma** — push tokens/components to a Figma file via Figma Console MCP.

Explicit target in the request wins; otherwise it's inferred from context and confirmed with a one-line ask. Each subsequent step is target-aware and reads the matching reference doc in Step 4.

## Installation

Anthropic skill format is cross-tool (Cowork, Claude Code, Cursor, Continue, Windsurf, Aider).

1. Open the runtime → Skills (in Cowork: Customize → Skills).
2. "+ Create skill" / "Upload a skill".
3. Drop the `.skill` file (a renamed zip of this folder), or upload the folder contents as a ZIP.
4. The server emits an opaque skillId.
5. Restart the runtime + open a new chat to activate.

### Install test

In a new chat:

```
amaca-frontend: build me a primary button that says "Continue"
```

Expected: the skill reads the bundled DESIGN.md (Step 1), confirms Amaca-scope, detects target HTML, maps to Components › Button (primary), generates code with token references only (`var(--primary-500)`, `var(--s-3)`), runs the verification pass, and hands off. If you get hardcoded values (`#F051D5`, `200ms`), the runtime isn't enforcing the spec — see the compatibility caveat below.

## Targets — what's required

| Target | Requires |
|---|---|
| HTML | nothing beyond the bundle |
| React | DESIGN.md v2.5.0+ (Multi-deploy compatibility) + Tailwind v4 with the `@theme` block from `theme.css`. Fallback: CSS modules with `var(--token)`. |
| Figma | Figma Console MCP installed + connected, Desktop Bridge plugin running. |

The token-name mapping across all three surfaces is canonical in **DESIGN.md Multi-deploy compatibility** — `var(--primary-500)` ↔ `bg-primary-500` ↔ Variable `color/primary/500`, all `#F051D5`.

## Gap handling

If a needed value isn't in DESIGN.md the token sections, or a component isn't in Components, the skill **does not extend silently**. It surfaces the gap and proposes three paths: (a) workaround with the nearest token, (b) planning release via the `amaca-release` skill, (c) refactor the intent. You decide; the skill waits.

## Skill ecosystem (the loop)

`amaca-frontend` **applies** DESIGN.md. Its companion `amaca-release` **evolves** DESIGN.md. A gap found during generation → planning → the spec gains a token/component via a release → the next generation uses it. Compounding.

## Runtime compatibility caveat

Designed and validated for Anthropic-stack runtimes (Claude Code, Cowork, Cursor, Continue, Windsurf, Aider), where the bundled DESIGN.md is read via explicit tool calls. For other vendors, compatibility is best-effort: models that treat an upload as context-embedding without an explicit read tend toward performative compliance (they announce reading the spec, then emit invented values). Always verify generated token values against DESIGN.md on a non-Anthropic runtime. For Gemini, the most reliable path is a Gem: SKILL.md as system instructions + DESIGN.md as a knowledge file.

## Versioning

- **v1.3.1** (2026-10-19) — HTML.md gains **Embedded hosts**: a host's unlayered reset outranks the base layer of `tokens.css`, so a page that runs inside a host restates its `body` colour, background and font unlayered, by token; verification check **H11** looks for it. Found on a landing published inside a sandboxed preview, whose headings rendered in the host's dark text. Same note in DESIGN.md Code conventions › CSS. Workflow unchanged. REACT.md's card micro-header reads `text-obsidian-300`, the neutral mono register of DESIGN.md v5.2.0 (`--obsidian-400` is disabled text, never a label).
- **v1.3.0** (2026-10-18) — re-bundle on DESIGN.md **v5.0.0**. The brand ramp is `--primary-*` (renamed from `--magenta-*`); REACT.md, HTML.md, FIGMA.md and the README speak the new names (`bg-primary-500`, `--color-primary-500`, `color/primary/500`). Pre-flight reads the two blocks every component section now carries, **Rules.** and **Variants.** (one axis per line, the default marked), and knows the two new ways the system ships: the npm package `amaca-design` and a shadcn registry item per component at `www.amaca.design/r/<name>.json`, whose `meta.amaca` repeats the contract. Workflow unchanged.
- **v1.2.2** (2026-09-24) — re-bundle on DESIGN.md **v4.2.0**: the focus rings are tokens (`--ring-halo`, `--ring-field`, `--ring-field-danger`) and the `.btn-primary` hover is `--sh-glow` over `--sh-3`. REACT.md and HTML.md reference them by name — `shadow-ring-halo`, `hover:shadow-[var(--sh-glow),var(--sh-3)]` — and R1 no longer tolerates an rgba() arbitrary value for the halo. Workflow unchanged.
- **v1.2.1** (2026-09-23) — re-bundle on DESIGN.md **v4.1.0** (Components › Chip, the state vocabulary gains `selected`, `.info-strip` leaves the registry, § Button points to its states). The Chip reaches the skill through the bundled spec: Step 1 reads it, and Posture #8 recognises `.chip` as registered. Reference docs realigned to the § 3.0.1 state index: REACT.md's button patterns had drifted from the contract on every axis — a grey disabled fill instead of `opacity 0.4`, an `obsidian-100` label, a `magenta-600` hover the § 6.3 exception forbids, `rounded-md`, a magenta focus outline and a `0.3` halo — and its card pattern taught two variants the registry does not have; HTML.md carried the same focus drift; FIGMA.md's state table listed states the index does not carry. The restated state lists are replaced by pointers to § 3.0.1, so they cannot go stale again. `claude-design-release` references now name `amaca-release`, which supersedes it. Numbered v1.2.1, not v1.1.11 as first stamped: v1.2.0 shipped on 2026-08-29 and this README never recorded it. Button sizes follow the v4.1.0 contract — heights 32 · 40 · 48 as `min-h-*`, 44 on coarse pointers — and the React patterns carry them. The bundled `tokens.css` moves its base rules into `@layer base`: unlayered, its `button` reset erased the Tailwind utilities REACT.md teaches, and the reference button rendered transparent. Workflow unchanged.
- **v1.2.0** (2026-08-29) — **the verifier ships**: `scripts/verify-output.py`, the executable form of the Step 6 checklist for the HTML target (token resolution, hex outside `:root`, px parity, registry closure, one-primary, focus-visible, reduced-motion, z scale, durations, spring-on-effects, no emoji). Read is not apply — a control described in prose is not a control; the 2026-08-27 marketplace run proved it by inventing card spacing the spec did not have. RIGID: output is deliverable only on exit 0; `python3` absent degrades loudly, never silently. Re-bundled on DESIGN.md v4.0.0 (card surfaces, `.card-meta`, seven promotions, `--t-caption` register).
- **v1.1.10** (2026-08-05) — re-bundle on DESIGN.md **v3.4.0** (component registry + state grammar). New checks: **H9 / R11 component registry lookup** (a class outside § 3.0 is `off-system` — stop, don't ship; `css-only` rows are used as-is and never extended) and **H10 / R12 state matrix completeness** (closed state vocabulary, `focus-visible` mandatory for anything focusable, `error` mandatory for every form control, `z-index` from the seven-layer scale). FIGMA.md F4 and F7 rewritten against the registry and the closed state list. Pre-flight now reads § 3.0 + § 3.0.1. This is the check that closes the `.pillar` gap: visual similarity is no longer coverage — coverage is a row in a table.
- **v1.1.9** (2026-07-14) — re-bundle on DESIGN.md **v3.2.0**; new RIGID motion rule: stat count-up (numeric stats compose from zero riding `--d-draw` · `--ease-decel`, reduced-motion jumps to target) — taught in HTML.md/REACT.md, verified in Step 6.
- **v1.1.8** (2026-06-22) — self-contained: bundle `tokens.css` + `theme.css` alongside the spec so the skill ships the actual token values. No workflow change.
- **v1.1.6** (2026-06-21) — re-bundle on DESIGN.md **v3.1.0** (Google `design.md` restructure) + v2.8.0 (Select viewport-aware placement). All reference docs reconciled: spec section citations converted from § numbers to NAMED sections to match the new grammar. Workflow unchanged.
- **v1.1.5** (2026-06-12) — re-bundle on DESIGN.md v2.7.2 (primary label weight ratified Medium 500). Workflow unchanged.
- **v1.1.4** (2026-06-12) — re-bundle on DESIGN.md v2.7.1 (Accessibility › Ratified exceptions APCA evidence + compliance mode, measured ratio ≈2.8:1, Code conventions › JavaScript runtime-token anti-drift rule). HTML.md a11y note updated in lockstep. Workflow unchanged.
- **v1.1.3** (2026-06-12) — re-bundle on DESIGN.md v2.7.0 (new `--d-draw` token, motion-token runtime helper, JS reduced-motion gate rule in Motion). Workflow unchanged.
- **v1.1.2** (2026-06-11) — re-bundle on DESIGN.md v2.6.1 (documentation reconciliation: Do's and Don'ts › Principles heading, Do's and Don'ts › Principles › Motion is a material signature-curve copy, Accessibility › Contrast pairs pointer to the Accessibility › Ratified exceptions ratified exception). Workflow unchanged.
- **v1.1.1** (2026-06-07) — re-bundle on DESIGN.md v2.6.0 (Components › Diagrams + Components › Button primary-button light-on-magenta exception, Accessibility › Ratified exceptions). HTML.md gains the ratified-exception a11y note. Workflow unchanged.
- **v1.1.0** (2026-05-25) — multi-target: HTML + React + Figma. Target detection (Step 2) + cross-target propose (Step 7). Three reference docs added (HTML.md, REACT.md, FIGMA.md). Posture #9 (cross-target consistency), anti-patterns #9–#10. Requires DESIGN.md v2.5.0+ for the React/Figma targets (Multi-deploy compatibility). HTML target works against v2.3.0+.
- **v1.0.2** (2026-05-24) — English rewrite for cross-vendor portability; Posture 0 (communication language).
- **v1.0.1** (2026-05-24) — class-name novelty check, 4 verification checks, 1 anti-pattern.
- **v1** (2026-05-24) — first version, HTML/CSS/JS only.

## Source of truth

- Amaca DS canonical: [github.com/angelomacaione/amaca-design](https://github.com/angelomacaione/amaca-design) + [amaca.design](https://amaca.design)
- License: MIT (the DESIGN.md spec). Use, learn from, fork.

## Credits

Skill design + DESIGN.md authoring: Angelo Macaione.
