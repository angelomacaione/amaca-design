#!/usr/bin/env python3
"""verify-output.py — is THIS generated artifact on-system?

Ships inside the amaca-frontend skill bundle and verifies the OUTPUT the
skill just generated — one HTML file per run. It is NOT verify-ds.py and
never converges with it: that script asks whether the design system itself
is coherent (spec <-> CSS <-> site <-> bundles) and runs at release, in the
repo; this one asks whether one generated artifact respects the closed
lists, and runs at generation time, wherever the skill runs. Different
question, different name, zero shared code — by rule (2026-08-27 proposal,
ratified 2026-08-29).

Reads its truth from the bundle's own copies of tokens.css and DESIGN.md,
which ship beside SKILL.md. Zero network, zero dependencies beyond the
standard library. Exit 0 = deliverable; anything else = not deliverable.

Usage:  python3 scripts/verify-output.py path/to/output.html
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent
TOKENS = BUNDLE / "tokens.css"
DESIGN = BUNDLE / "DESIGN.md"


def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    out_path = Path(sys.argv[1])
    if not out_path.exists():
        print(f"no such file: {out_path}")
        return 2
    out = read(out_path)
    tokens = read(TOKENS)
    design = read(DESIGN)
    if not tokens or not design:
        print("bundle incomplete: tokens.css / DESIGN.md not found beside SKILL.md")
        return 2

    findings = []
    say = findings.append

    # the closed lists, read from the bundle at run time — never re-typed here
    declared = set(re.findall(r"(--[a-z0-9-]+)\s*:", tokens))
    px_of = {}
    for name, val in re.findall(r"(--[a-z0-9-]+):\s*(\d+)px", tokens):
        px_of.setdefault(val, []).append(name)

    comp = design[design.find("## Components"):]
    comp = comp[:comp.find("\n## ", 1)]
    allowed = set()
    for row in re.finditer(r"^\|[^|]+\|([^|]+)\|\s*(?:canonical|rule)\s*\|", comp, re.M):
        allowed.update(re.findall(r"`\.([\w-]+)`", row.group(1)))
    for m in re.finditer(r"```html\n([\s\S]*?)```", comp):
        for cm in re.finditer(r'class="([^"]*)"', m.group(1)):
            allowed.update(cm.group(1).split())
    allowed.update(re.findall(r"`\.([\w-]+)`", comp))

    css_blob = "\n".join(re.findall(r"<style[^>]*>([\s\S]*?)</style>", out))
    css_blob += "\n" + "\n".join(re.findall(r'style="([^"]*)"', out))

    # 1 · every var() resolves against the shipped scale, or against a property the output
    #     declares itself: --hue, the operand of the system's own tint idiom (v5.3.0)
    local = set(re.findall(r"(?<![\w-])(--[a-z0-9-]+)\s*:", re.sub(r":root\s*{[^}]*}", "", out)))
    for tok in sorted(set(re.findall(r"var\((--[a-z0-9-]+)", out))):
        if tok not in declared and tok not in local:
            say(f"var({tok}) does not exist in tokens.css — invented token")

    # 2 · no raw hex outside a :root block (the pasted token file is the one
    #     place hex may live; everywhere else the name is the value)
    no_root = re.sub(r":root\s*{[^}]*}", "", out)
    for hx in sorted(set(re.findall(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b", no_root))):
        say(f"raw hex {hx} outside :root — reference the token by name")

    # 3 · no raw px where a token holds the same value (the drift check 03
    #     exists to catch in the system, applied to the output)
    for prop, val in re.findall(
            r"(font-size|border-radius|gap|padding|margin)\s*:\s*(\d+)px", css_blob):
        fam = {"font-size": "--t-", "border-radius": "--r-"}.get(prop, "--s-")
        hit = [t for t in px_of.get(val, []) if t.startswith(fam)]
        if hit:
            say(f"{prop}:{val}px has an exact token — use var({hit[0]})")

    # 4 · every class is spec-sanctioned (registry parts + § 3 examples).
    #     The .pillar incident: a Card variant invented under a new name.
    used = set()
    for m in re.finditer(r'class="([^"]*)"', out):
        used.update(m.group(1).split())
    for cls in sorted(used):
        if cls not in allowed:
            say(f'class "{cls}" is not in the component registry or any § 3 '
                f"example — off-system candidate: stop and ask, never invent")

    # 5 · one primary per screen
    n = len(re.findall(r'class="[^"]*\bbtn-primary\b[^"]*"', out))
    if n > 1:
        say(f".btn-primary appears {n} times — one primary per screen")

    # 6 · focus-visible rides every generated pressable style
    if re.search(r"<(button|a\s|input|select|textarea)", out) and css_blob.strip():
        if ".btn" in css_blob or "button" in css_blob:
            if ":focus-visible" not in css_blob:
                say("pressables are styled and no :focus-visible rule exists "
                    "— § 6 floor #5")

    # 7 · motion never ships without its reduced-motion fallback
    if re.search(r"transition\s*:|animation\s*:|@keyframes", css_blob):
        if "prefers-reduced-motion" not in out:
            say("motion is declared and prefers-reduced-motion is absent")

    # 8 · z-index at or above the sticky layer comes from the scale
    for z in re.findall(r"z-index\s*:\s*(\d+)", css_blob):
        if int(z) >= 10:
            say(f"raw z-index:{z} — at or above the sticky layer the "
                f"seven-level scale is the only source")

    # 9 · durations are tokens, not literals. The kill-switch's 0.01ms (or 0s) inside
    #     @media (prefers-reduced-motion: reduce) is what the system prescribes, not a
    #     duration (v5.3.0, aligned with check_compliance); any other literal there still is.
    calm = []
    for m in re.finditer(r"@media[^{]*prefers-reduced-motion\s*:\s*reduce[^{]*\{", css_blob):
        depth, i = 1, m.end()
        while i < len(css_blob) and depth:
            depth += {"{": 1, "}": -1}.get(css_blob[i], 0)
            i += 1
        calm.append((m.start(), i))
    raw = set()
    for d in re.finditer(r"(?:transition|animation)[^;{}]*", css_blob):
        for t in re.finditer(r"(?<![\w.-])(\d*\.?\d+)(ms|s)\b", d.group(0)):
            v = float(t.group(1)) * (1 if t.group(2) == "ms" else 1000)
            at = d.start() + t.start()
            if v < 1 and any(a <= at < b for a, b in calm):
                continue
            raw.add(t.group(0))
    for ms in sorted(raw):
        say(f"raw duration {ms} — durations ride the --d-* scale")

    # 10 · --ease-spring never rides an effect property (§ 08.3 RIGID)
    for line in css_blob.splitlines():
        if "--ease-spring" in line and re.search(
                r"\b(color|background|opacity|box-shadow|filter|border-color)\b", line):
            say(f"--ease-spring on an effect property: {line.strip()[:70]}")

    # 11 · no emoji, anywhere (hard convention 2026-06-29)
    if re.search(r"[\U0001F000-\U0001FAFF☀-➿]", out):
        say("emoji in the output — hard convention: none, anywhere")

    # 12 · nothing the page needs to draw comes from a CDN alone (DESIGN.md, the site's own conduct, v5.3.0):
    #      a blocked CDN or a page opened from disk leaves its charts and diagrams empty. Analytics excepted.
    for u in re.findall(r'<script\b[^>]*\bsrc="(https?://[^"]+)"', out) + re.findall(r'\bimport\b[^;"\']*?["\'](https?://[^"\']+)["\']', out):
        if "analytics" not in u:
            say(f"script from the network: {u[:70]} — vendor it beside the page, pinned")

    # 13 · a floating panel rides the top layer (v5.3.0): an absolute menu, listbox, picker or tooltip with a
    #      z-index, never shown with showPopover(), is covered or cut by any transformed or clipped ancestor
    floating = re.search(r"\.(select-menu|dp-popover|tp-popover|tooltip)\b[^{]*\{[^}]*position\s*:\s*absolute", css_blob)
    if floating and "showPopover" not in out and " popover" not in out:
        say(f".{floating.group(1)} floats as an absolute box — lift it into the top layer (popover + showPopover)")

    # 14 · labels are a register, quotes have one (DESIGN.md v6.0.0, Typography): the removed mono names never
    #      come back, and italic is the quote register's, written as var(--font-style-quote), never by hand
    for old in re.findall(r"--font-mono|--tr-mono\b|\bfont-mono\b|\btracking-mono\b|\bty-mono\b", out):
        say(f"{old} was removed in 6.0.0 — use --font-sans with --tr-label (tracking-label)")
        break
    no_faces = re.sub(r"@font-face\s*\{[^}]*\}", "", out)   # a pasted tokens.css declares the italic cuts
    if re.search(r"font-style\s*:\s*italic", no_faces) or re.search(r"class(?:Name)?=[\"'{][^\"'}]*\bitalic\b", out):
        say("italic written by hand — quoted text takes var(--font-style-quote); emphasis takes weight")

    W = 66
    print("\n  AMACA - generated-output verifier")
    print("  " + "-" * W)
    if findings:
        for f in findings:
            print(f"  [FAIL] {f}")
        print("  " + "-" * W)
        print(f"  {len(findings)} finding(s) - NOT deliverable. Fix, or surface "
              f"the gap with the three paths; never work around the verifier.\n")
        return 1
    print("  [PASS] token resolution, hex, px parity, registry, one-primary,")
    print("         focus-visible, reduced-motion, z scale, durations,")
    print("         spring-on-effects, no-emoji, no CDN runtime, top layer,")
    print("         label and quote registers")
    print("  " + "-" * W)
    print("  0 findings - deliverable. Paste this verdict in the hand-off.")
    print("  Not covered (needs a render): touch-target geometry, contrast,")
    print("  85/10/5 by area. The prose checklist in Step 6 still applies.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
