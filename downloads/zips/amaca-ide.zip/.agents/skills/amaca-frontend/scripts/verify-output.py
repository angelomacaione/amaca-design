#!/usr/bin/env python3
"""verify-output.py — is THIS generated artifact on-system?

Ships inside the amaca-frontend skill bundle and verifies the OUTPUT the
skill just generated — one HTML file per run. It is NOT verify-ds.py and
never converges with it: that script asks whether the design system itself
is coherent (spec <-> CSS <-> site <-> bundles) and runs at release, in the
repo; this one asks whether one generated artifact respects the closed
lists, and runs at generation time, wherever the skill runs. Different
question, different name, zero shared code — by rule (2026-08-27 proposal,
ratified 2026-08-29).

Reads its truth from the bundle's own copies of tokens.css and DESIGN.md,
which ship beside SKILL.md. Zero network, zero dependencies beyond the
standard library. Exit 0 = deliverable; anything else = not deliverable.

Usage:  python3 scripts/verify-output.py path/to/output.html
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent
TOKENS = BUNDLE / "tokens.css"
DESIGN = BUNDLE / "DESIGN.md"


def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    out_path = Path(sys.argv[1])
    if not out_path.exists():
        print(f"no such file: {out_path}")
        return 2
    out = read(out_path)
    tokens = read(TOKENS)
    design = read(DESIGN)
    if not tokens or not design:
        print("bundle incomplete: tokens.css / DESIGN.md not found beside SKILL.md")
        return 2

    findings = []
    say = findings.append

    # the closed lists, read from the bundle at run time — never re-typed here
    declared = set(re.findall(r"(--[a-z0-9-]+)\s*:", tokens))
    px_of = {}
    for name, val in re.findall(r"(--[a-z0-9-]+):\s*(\d+)px", tokens):
        px_of.setdefault(val, []).append(name)

    comp = design[design.find("## Components"):]
    comp = comp[:comp.find("\n## ", 1)]
    allowed = set()
    for row in re.finditer(r"^\|[^|]+\|([^|]+)\|\s*canonical\s*\|", comp, re.M):
        allowed.update(re.findall(r"`\.([\w-]+)`", row.group(1)))
    for m in re.finditer(r"```html\n([\s\S]*?)```", comp):
        for cm in re.finditer(r'class="([^"]*)"', m.group(1)):
            allowed.update(cm.group(1).split())
    allowed.update(re.findall(r"`\.([\w-]+)`", comp))

    css_blob = "\n".join(re.findall(r"<style[^>]*>([\s\S]*?)</style>", out))
    css_blob += "\n" + "\n".join(re.findall(r'style="([^"]*)"', out))

    # 1 · every var() resolves against the shipped scale
    for tok in sorted(set(re.findall(r"var\((--[a-z0-9-]+)", out))):
        if tok not in declared:
            say(f"var({tok}) does not exist in tokens.css — invented token")

    # 2 · no raw hex outside a :root block (the pasted token file is the one
    #     place hex may live; everywhere else the name is the value)
    no_root = re.sub(r":root\s*{[^}]*}", "", out)
    for hx in sorted(set(re.findall(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b", no_root))):
        say(f"raw hex {hx} outside :root — reference the token by name")

    # 3 · no raw px where a token holds the same value (the drift check 03
    #     exists to catch in the system, applied to the output)
    for prop, val in re.findall(
            r"(font-size|border-radius|gap|padding|margin)\s*:\s*(\d+)px", css_blob):
        fam = {"font-size": "--t-", "border-radius": "--r-"}.get(prop, "--s-")
        hit = [t for t in px_of.get(val, []) if t.startswith(fam)]
        if hit:
            say(f"{prop}:{val}px has an exact token — use var({hit[0]})")

    # 4 · every class is spec-sanctioned (registry parts + § 3 examples).
    #     The .pillar incident: a Card variant invented under a new name.
    used = set()
    for m in re.finditer(r'class="([^"]*)"', out):
        used.update(m.group(1).split())
    for cls in sorted(used):
        if cls not in allowed:
            say(f'class "{cls}" is not in the component registry or any § 3 '
                f"example — off-system candidate: stop and ask, never invent")

    # 5 · one primary per screen
    n = len(re.findall(r'class="[^"]*\bbtn-primary\b[^"]*"', out))
    if n > 1:
        say(f".btn-primary appears {n} times — one primary per screen")

    # 6 · focus-visible rides every generated pressable style
    if re.search(r"<(button|a\s|input|select|textarea)", out) and css_blob.strip():
        if ".btn" in css_blob or "button" in css_blob:
            if ":focus-visible" not in css_blob:
                say("pressables are styled and no :focus-visible rule exists "
                    "— § 6 floor #5")

    # 7 · motion never ships without its reduced-motion fallback
    if re.search(r"transition\s*:|animation\s*:|@keyframes", css_blob):
        if "prefers-reduced-motion" not in out:
            say("motion is declared and prefers-reduced-motion is absent")

    # 8 · z-index at or above the sticky layer comes from the scale
    for z in re.findall(r"z-index\s*:\s*(\d+)", css_blob):
        if int(z) >= 10:
            say(f"raw z-index:{z} — at or above the sticky layer the "
                f"seven-level scale is the only source")

    # 9 · durations are tokens, not literals
    for ms in sorted(set(re.findall(r"(?:transition|animation)[^;]*?\b(\d+m?s)\b",
                                    css_blob))):
        say(f"raw duration {ms} — durations ride the --d-* scale")

    # 10 · --ease-spring never rides an effect property (§ 08.3 RIGID)
    for line in css_blob.splitlines():
        if "--ease-spring" in line and re.search(
                r"\b(color|background|opacity|box-shadow|filter|border-color)\b", line):
            say(f"--ease-spring on an effect property: {line.strip()[:70]}")

    # 11 · no emoji, anywhere (hard convention 2026-06-29)
    if re.search(r"[\U0001F000-\U0001FAFF☀-➿]", out):
        say("emoji in the output — hard convention: none, anywhere")

    W = 66
    print("\n  AMACA - generated-output verifier")
    print("  " + "-" * W)
    if findings:
        for f in findings:
            print(f"  [FAIL] {f}")
        print("  " + "-" * W)
        print(f"  {len(findings)} finding(s) - NOT deliverable. Fix, or surface "
              f"the gap with the three paths; never work around the verifier.\n")
        return 1
    print("  [PASS] token resolution, hex, px parity, registry, one-primary,")
    print("         focus-visible, reduced-motion, z scale, durations,")
    print("         spring-on-effects, no-emoji")
    print("  " + "-" * W)
    print("  0 findings - deliverable. Paste this verdict in the hand-off.")
    print("  Not covered (needs a render): touch-target geometry, contrast,")
    print("  85/10/5 by area. The prose checklist in Step 6 still applies.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
