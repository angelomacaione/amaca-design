# Amaca — Cursor · Copilot · Codex

Scoped rules: amaca-core always on, amaca-html and amaca-react on the files they govern, the Copilot mirror and the agent skill unpacked.

## How to install

1. Unzip at the repo root: `.cursor/rules/` for Cursor, `.github/` for Copilot, `.agents/skills/` for Codex.
2. AGENTS.md goes at the root only if you have none; otherwise paste it under `## Amaca` in yours.
3. **Continue**: copy `.cursor/rules/amaca-core.mdc` into `.continue/rules/amaca.md`; it keeps its frontmatter.
4. Needs a frontier-tier model: on a lighter one the spec is read as context, not as instructions (§ 03.3).

## What's inside

- `.cursor/rules/amaca-core.mdc`
- `.cursor/rules/amaca-html.mdc`
- `.cursor/rules/amaca-react.mdc`
- `.github/copilot-instructions.md`
- `.github/instructions/amaca-html.instructions.md`
- `.github/instructions/amaca-react.instructions.md`
- `.agents/skills/amaca-frontend/DESIGN.md`
- `.agents/skills/amaca-frontend/FIGMA.md`
- `.agents/skills/amaca-frontend/HTML.md`
- `.agents/skills/amaca-frontend/REACT.md`
- `.agents/skills/amaca-frontend/README.md`
- `.agents/skills/amaca-frontend/SKILL.md`
- `.agents/skills/amaca-frontend/scripts/verify-output.py`
- `.agents/skills/amaca-frontend/theme.css`
- `.agents/skills/amaca-frontend/tokens.css`
- `AGENTS.md`
- `DESIGN.md`
- `tokens.css`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
