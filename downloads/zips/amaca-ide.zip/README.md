# Amaca — IDE (Cursor + Copilot)
**Where it goes** `.cursor/rules/amaca.mdc` → your `.cursor/rules/`; `.github/copilot-instructions.md` → your `.github/`; `AGENTS.md` → repo root.
**Use** The Cursor rule auto-attaches on CSS/HTML/JSX/TSX (alwaysApply:false + globs); Copilot reads its file repo-wide.
**Verify** Edit a .tsx: tokens by name, canonical classes, gaps surfaced not invented.
**In this bundle** .cursor/rules/amaca.mdc · .github/copilot-instructions.md · AGENTS.md · tokens.css · DESIGN.md.

— Amaca · MIT · https://amaca.design
