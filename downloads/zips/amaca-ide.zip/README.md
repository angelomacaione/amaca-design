# Amaca — IDE bundle (Cursor + Copilot)

Core + per-target rules that make your AI tools reference Amaca tokens by name.

- `.cursor/rules/amaca-core.mdc` — alwaysApply: token discipline + governance + a11y floor.
- `.cursor/rules/amaca-html.mdc` — globs CSS/HTML/Vue/Svelte.
- `.cursor/rules/amaca-react.mdc` — globs JSX/TSX (Tailwind v4 @theme).
- `.github/copilot-instructions.md` — repo-wide core mirror.
- `.github/instructions/amaca-{html,react}.instructions.md` — per-target applyTo.
- `AGENTS.md` — universal agent rules (repo root).

Drop `.cursor/` and `.github/` into your repo, `AGENTS.md` at root. On conflict, DESIGN.md wins.
