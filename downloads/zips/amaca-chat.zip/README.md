# Amaca — ChatGPT · Gemini · any chat

A self-contained paste-in, every token value and every component part inlined, no companion files.

## How to install

1. **ChatGPT**: a Project or a custom GPT, with `AI-INSTRUCTIONS.md` as its instructions.
2. **Gemini**: Customize → Skills → Create → Create manually, and paste `AI-INSTRUCTIONS.md` as the instructions. Gems retire on 17 November 2026.
3. **Any other chat**: attach the file and start with **Use this as the canonical reference for tokens, components and voice.**
4. Needs a frontier-tier model: on a lighter one the spec is read as context, not as instructions (§ 03.3).

## What's inside

- `AI-INSTRUCTIONS.md`
- `README.md` (this file)

On conflict, DESIGN.md wins. — Amaca · MIT · https://amaca.design
