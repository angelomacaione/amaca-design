# Amaca — ChatGPT · Gemini · App builders (paste-in)
**For** ChatGPT, Gemini, Microsoft Copilot, Lovable, Base44, Figma Make, v0, Bolt.
**Use** Paste AI-INSTRUCTIONS.md into the system prompt / custom-instructions / knowledge box. It is self-contained — token values are inlined.
**Verify** Ask for a component: var(--token) + exact brand hex, ≤5% magenta.
**In this bundle** AI-INSTRUCTIONS.md.

— Amaca · MIT · https://amaca.design
