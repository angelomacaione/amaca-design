---
type: skill-reference-doc
parent_skill: amaca-frontend
target: React
version: 1.0
created: 2026-05-25
tags:
  - skill-reference
  - amaca
  - react
  - tailwind-v4
---

# React target — reference doc for amaca-frontend

> Conventions, patterns, and verification checks specific to **React (with Vue/Svelte applicable) + Tailwind v4** target. Read by `amaca-frontend` SKILL.md Step 4 when target = React. Does not stand alone — requires the parent SKILL.md and DESIGN.md as canonical context.

## When this target applies

- React component (functional, Hooks)
- Build pipeline available (Vite, Next.js, Remix, etc.)
- Tailwind v4 installed and configured with `@theme` block in theme.css
- Component lives in a real project repo (not Cowork single-file artifact)

If the user wants stand-alone artifact without build → switch to HTML target. If the user wants Figma push → switch to Figma target.

## Prerequisites — DESIGN.md v2.5.0 + Tailwind v4 @theme

This target requires DESIGN.md v2.5.0+ (Multi-deploy compatibility) and theme.css providing the Tailwind v4 `@theme` block with namespaced token names. If DESIGN.md is < v2.5.0 OR theme.css not yet migrated:

1. **Preferred**: ASK user to schedule release via `claude-design-release` skill (MINOR bump → v2.5.0, additive non-breaking).
2. **Fallback**: use CSS modules with raw `var(--token-name)` syntax (legacy compatibility, no utility classes). Less ergonomic but functionally correct. Flag as `compliance: best-effort` in hand-off.

Detect mode at Step 4:
- Read theme.css (or tokens.css). If `@theme {` block found → utility classes available.
- If `:root {` only → CSS modules fallback mode.

## Naming convention — Tailwind v4 @theme

Tokens use namespace prefix to auto-generate utility classes:

| DESIGN.md old name | Tailwind v4 namespaced | Generated utilities |
|---|---|---|
| `--magenta-500` | `--color-magenta-500` | `bg-magenta-500`, `text-magenta-500`, `border-magenta-500`, `fill-magenta-500`, `stroke-magenta-500` |
| `--obsidian-800` | `--color-obsidian-800` | `bg-obsidian-800`, etc. |
| `--s-4` | `--spacing-4` | `p-4`, `m-4`, `px-4`, `py-4`, `gap-4`, `space-x-4`, etc. |
| `--r-lg` | `--radius-lg` | `rounded-lg` |
| `--t-body` | `--text-body` | `text-body` |
| `--font-sans` | `--font-sans` | `font-sans` |
| `--d-quick` | `--duration-quick` | `duration-quick` |
| `--ease-decel` | `--ease-decel` | `ease-decel` (when used in transition-timing-function) |

For motion durations/easings, Tailwind v4 transition utilities consume the variables: `transition duration-quick ease-decel`.

## Component patterns

### Pattern 1 — utility classes only (preferred when stateless)

```tsx
export function PrimaryButton({ children, ...props }: ButtonProps) {
  return (
    <button
      className="
        bg-magenta-500 text-obsidian-100
        px-6 py-3 rounded-md
        font-sans text-body
        transition duration-quick ease-standard
        hover:bg-magenta-600
        focus-visible:outline-2 focus-visible:outline-magenta-500 focus-visible:outline-offset-2
        focus-visible:shadow-[0_0_0_4px_rgba(240,81,213,0.3)]
        disabled:bg-obsidian-500 disabled:text-obsidian-400 disabled:cursor-not-allowed
        motion-reduce:transition-none
      "
      {...props}
    >
      {children}
    </button>
  );
}
```

### Pattern 2 — utility classes + clsx for dynamic state

```tsx
import { clsx } from 'clsx';

export function Card({ variant, children }: CardProps) {
  return (
    <div className={clsx(
      'rounded-lg p-8 border',
      variant === 'default' && 'bg-obsidian-800 border-obsidian-700',
      variant === 'elevated' && 'bg-obsidian-850 border-obsidian-600 shadow-sh-2',
      variant === 'danger' && 'bg-obsidian-800 border-danger',
    )}>
      {children}
    </div>
  );
}
```

### Pattern 3 — CSS modules fallback (when no Tailwind v4)

```css
/* PrimaryButton.module.css */
.btnPrimary {
  background: var(--magenta-500);
  color: var(--obsidian-100);
  padding: var(--s-3) var(--s-6);
  border-radius: var(--r-md);
  transition: background var(--d-quick) var(--ease-standard);
}
.btnPrimary:hover { background: var(--magenta-600); }
.btnPrimary:focus-visible {
  outline: 2px solid var(--magenta-500);
  outline-offset: 2px;
  box-shadow: 0 0 0 4px rgba(240, 81, 213, 0.3);
}
@media (prefers-reduced-motion: reduce) {
  .btnPrimary { transition: none; }
}
```

```tsx
import styles from './PrimaryButton.module.css';

export function PrimaryButton({ children, ...props }: ButtonProps) {
  return <button className={styles.btnPrimary} {...props}>{children}</button>;
}
```

## Import theme.css in React project

### Vite / Next.js / Remix

In project entry CSS (e.g., `src/index.css` or `app/globals.css`):
```css
@import "tailwindcss";
@import "../../path/to/theme.css";  /* contains @theme block with Amaca tokens */
```

Tailwind v4 auto-detects the `@theme` block, generates utility classes, exposes tokens as CSS variables at runtime.

If `theme.css` is in the Amaca repo (`angelomacaione/amaca-design`), install as dependency:
```bash
npm install github:angelomacaione/amaca-design
```
Then:
```css
@import "tailwindcss";
@import "amaca-design/styles/theme.css";
```

## Component file layout convention

```
components/
├── ui/
│   ├── Button.tsx
│   ├── Card.tsx
│   ├── Input.tsx
│   └── index.ts                    # barrel export
├── domain/
│   ├── PipelineCard.tsx            # composite using ui primitives
│   └── DashboardHeader.tsx
└── (no Button.module.css if using utility classes pattern 1-2)
```

Filename: PascalCase matching component name (`PrimaryButton.tsx`). Barrel exports via `index.ts`.

## Motion pairing & Spatial vs Effects (RIGID)

User-triggered states: `duration-quick ease-standard`. System-triggered reveals: `duration-base ease-decel`. Spatial properties (transform, size, position) may use any easing including `ease-spring`; effect properties (color, background, opacity, shadow) never take `ease-spring` or any overshoot curve. Per-component pairs are ratified in `DESIGN.md → Motion` (motion index) — read the component's rows before animating it; no rows = default pairing.

## Reduced-motion (mandatory for React too)

Tailwind v4 `motion-reduce:` variant or media query:
```tsx
<div className="transition duration-base ease-decel motion-reduce:transition-none">
  ...
</div>
```

For complex orchestration:
```css
@media (prefers-reduced-motion: reduce) {
  .hero-reveal { transition: none; transform: none; }
}
```

## Verification checks — React-specific

In addition to baseline checks (SKILL.md § Posture 6):

### R1. Grep hardcoded values in JSX
Regex: `(className|style)="[^"]*([0-9]+px|#[0-9A-Fa-f]{3,8})[^"]*"`. Match > 0 = regression (except documented exceptions). Note: Tailwind arbitrary values like `shadow-[0_0_0_4px_rgba(240,81,213,0.3)]` are tolerated ONLY for box-shadow glow halos and other patterns explicitly documented in Accessibility › Focus visibility.

### R2. Tailwind utility class existence
For every `bg-*`, `text-*`, `p-*`, `rounded-*`, `duration-*`, `ease-*` etc. utility, verify the corresponding token exists in `@theme` block of theme.css. Pattern incident: `bg-magenta-550` typed instead of `bg-magenta-500` → utility doesn't exist → Tailwind silently produces nothing.

### R3. `:focus-visible` (not `:focus`) for keyboard interaction
React JSX: use `focus-visible:` Tailwind variant, not `focus:`. The latter triggers on mouse click which is rarely desired (Accessibility › Focus visibility).

### R4. `motion-reduce:` variant or media query present
Every component with transition or animation must have explicit reduced-motion override. Verify presence.

### R5. Stat count-up (RIGID)
Numeric stats/KPIs compose from zero to target on entrance — `--d-draw` · `--ease-decel`, landing exactly on the final value (use Motion One / `animate()` with `useReducedMotion()` gating: reduced motion jumps straight to the target). A static stat number where a count-up belongs is off-system. Read duration and curve off `:root` — never hand-copy the values.

### R6. Single .btn-primary per page check (React-aware)
Static analysis is hard in React (component used in N places at runtime). Soft check: enumerate `<PrimaryButton>` (or component named `BtnPrimary`, `ButtonPrimary`) imports in page-level files. If > 1 used per page route → warning.

### R7. clsx not classnames
If conditional className is needed, use `clsx` (lighter, modern) not legacy `classnames`. Verify package.json.

### R8. No inline `style={{...}}` for token values
React inline `style` prop with raw values violates token discipline. Exception: dynamic positioning calculated at runtime (e.g., `style={{ '--offset': `${px}px` }}` then className reads `var(--offset)`).

### R9. Cross-target consistency (Posture #9)
If HTML version of same component was generated in session, diff tokens. Example: HTML uses `var(--magenta-500)`, React must use `bg-magenta-500` (not `bg-magenta-600`). Drift = surface.

### R10. Spring-on-effect + raw durations
Grep `ease-spring` (utility or `var(--ease-spring)`) applied to color/background/opacity/shadow transitions → finding: spring rides transform/size only (spec § Motion RIGID). Raw `ms` durations where a `duration-*` utility exists (ratified continuous loops excepted) → finding.

### R11. Component registry lookup (Components › § 3.0)
Same table lookup as H9, before the component is written. A `className` outside the § 3.0 registry is `off-system` — surface it, don't ship it. `css-only` rows are used as-is and never extended. In React the failure mode is subtler: a prop that introduces a new visual variant (`<Badge tone="brand-soft">`) is a new component if the registry has no row for it.

### R12. State matrix completeness (Components › § 3.0.1)
States come from the closed vocabulary and must match the § 3.0.1 state index. `focus-visible` is mandatory for anything focusable — in Tailwind that is `focus-visible:` variants, never `focus:` (R3). `error` is mandatory for every form control and rides `aria-invalid`, not a colour prop. `z-index` ≥ 10 comes from the seven-layer scale.

## Anti-patterns specific to React target

1. **CSS-in-JS (styled-components, Emotion) for token application.** Tailwind v4 utility classes or CSS modules are canonical. CSS-in-JS adds runtime overhead and obscures token usage from grep.

2. **Inline Tailwind arbitrary values for tokens that exist.** `bg-[#F051D5]` is wrong — use `bg-magenta-500`. Arbitrary values reserved for explicit one-off patterns (glow halos, exact box-shadows).

3. **`className={\`prefix-${variant}\`}` template strings.** Tailwind PurgeCSS / JIT can't statically analyze dynamic strings. Use clsx with full classnames listed:
   ```tsx
   // ❌
   className={`bg-${color}-500`}
   // ✅
   className={clsx(color === 'magenta' && 'bg-magenta-500', color === 'obsidian' && 'bg-obsidian-500')}
   ```

4. **Forgetting `'use client'` for components with state/hooks in Next.js App Router.** Server components can render Amaca primitives, but interactive ones (state, effects) need `'use client'`.

5. **Importing theme.css per-component.** Import once in entry CSS. Per-component imports cause duplicate Tailwind generation.

## Hand-off output format — React

```
✅ Component generated: [name] (target: React)
- Compliance: strict Amaca DS v[X.Y.Z]
- Tailwind v4 mode: [utility classes | CSS modules fallback]
- Tokens used: N (color), N (spacing), N (radius), N (motion)
- Components: [the relevant Components specs]
- Accessibility: floor 7/7 passed, WCAG AA verified
- Lines: TSX XX / CSS XX (if modules) / 0 (if utility-only)
- File: [path]

Optional next actions:
- Run `npm run build` to verify Tailwind picks up utility classes
- Run linter (ESLint with tailwindcss plugin recommended for class order)
- Storybook visual test if integrated
- Test reduced-motion: System Preferences → Accessibility → Display → Reduce motion
- Test focus-visible: Tab through interactive elements (NOT mouse click)
```

## Cross-references

- [[SKILL.md]] — parent skill
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Multi-deploy compatibility (v2.5.0+) — naming convention canonical
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) the token sections — source of truth
- [amaca-design/DESIGN.md](https://github.com/angelomacaione/amaca-design/blob/main/DESIGN.md) Accessibility
- [[HTML.md]] — sibling target reference
- [[FIGMA.md]] — sibling target reference
- [[2026-05-25 - Prior art lifesized + decisione Tailwind v4 nativo]] — decision doc per Tailwind v4 path
- Tailwind v4 @theme docs: https://tailwindcss.com/docs/theme
